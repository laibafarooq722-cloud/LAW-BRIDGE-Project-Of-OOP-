package lawbridge.data;

import lawbridge.models.Lawyer;
import lawbridge.models.User;
import java.util.ArrayList;
import java.util.List;

// ENCAPSULATION: All data private, accessed via methods
// ABSTRACTION: Hides data management from UI
public class DataStore {

    private static DataStore instance;

    private List<Lawyer> lawyers = new ArrayList<>();
    private List<User>   users   = new ArrayList<>();

    // App statistics
    private final int totalCasesSolved = 1247;
    private final int totalWins        = 983;
    private final int totalLosses      = 264;
    private final int totalClients     = 1543;
    private final int yearsActive      = 8;

    private DataStore() {
        initializeLawyers();
        // Seed three demo accounts; real users are added on the fly
        users.add(new User("admin", "admin123", "admin@lawbridge.pk"));
        users.add(new User("user",  "user123",  "user@lawbridge.pk"));
        users.add(new User("demo",  "demo123",  "demo@lawbridge.pk"));
    }

    public static DataStore getInstance() {
        if (instance == null) instance = new DataStore();
        return instance;
    }

    // ── LOGIN / REGISTER ──────────────────────────────────────────────────────
    /**
     * Try to authenticate.  If the username doesn't exist yet, create an
     * account automatically (any username / password accepted).
     */
    public User authenticate(String username, String password) {
        // 1. Look for existing user
        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                if (u.checkPassword(password)) return u;
                else return null; // wrong password for known user
            }
        }
        // 2. New user — register automatically
        User newUser = new User(username, password, username.toLowerCase() + "@lawbridge.pk");
        users.add(newUser);
        return newUser;
    }

    // ── LAWYERS ───────────────────────────────────────────────────────────────
    public List<Lawyer> getAllLawyers() { return lawyers; }

    public List<Lawyer> getLawyersBySpecialization(String spec) {
        List<Lawyer> out = new ArrayList<>();
        for (Lawyer l : lawyers) if (l.getSpecialization().equals(spec)) out.add(l);
        return out;
    }

    // ── STATISTICS ────────────────────────────────────────────────────────────
    public int getTotalCasesSolved() { return totalCasesSolved; }
    public int getTotalWins()        { return totalWins; }
    public int getTotalLosses()      { return totalLosses; }
    public int getTotalClients()     { return totalClients; }
    public int getYearsActive()      { return yearsActive; }

    // ── CASE TYPES ────────────────────────────────────────────────────────────
    public String[] getCaseTypes() {
        return new String[]{
            "Select Case Type...",
            "Criminal Case",
            "Family Law (Divorce / Custody)",
            "Property Dispute",
            "Corporate / Business Law",
            "Civil Suit",
            "Labour / Employment Issue",
            "Other"
        };
    }

    public String getSpecializationForCase(String caseType) {
        switch (caseType) {
            case "Criminal Case":                return "Criminal Law";
            case "Family Law (Divorce / Custody)": return "Family Law";
            case "Property Dispute":             return "Property Law";
            case "Corporate / Business Law":     return "Corporate Law";
            case "Civil Suit":                   return "Civil Law";
            case "Labour / Employment Issue":    return "Labour Law";
            default: return null;
        }
    }

    // ── DATA INIT ─────────────────────────────────────────────────────────────
    private void initializeLawyers() {
        // Criminal Law
        lawyers.add(new Lawyer("Adv. Kamran Hussain",  48,"35201-1234567-1","Criminal Law", 22,310,270,40,75000,"Senior criminal defence attorney. Former Public Prosecutor with 22 years of courtroom excellence."));
        lawyers.add(new Lawyer("Adv. Sana Mirza",      38,"35202-2345678-2","Criminal Law", 12,180,150,30,55000,"White-collar crime & financial fraud specialist. Known for meticulous case preparation."));
        lawyers.add(new Lawyer("Adv. Tariq Mahmood",   55,"35203-3456789-3","Criminal Law", 28,420,370,50,90000,"Veteran who has appeared before the Supreme Court of Pakistan multiple times."));
        // Family Law
        lawyers.add(new Lawyer("Adv. Nadia Akhtar",    42,"35204-4567890-4","Family Law",   16,240,210,30,45000,"Compassionate family law expert handling divorce, custody and inheritance with sensitivity."));
        lawyers.add(new Lawyer("Adv. Bilal Chaudhry",  35,"35205-5678901-5","Family Law",    9,130,110,20,38000,"Certified family mediator focused on child custody and maintenance."));
        lawyers.add(new Lawyer("Adv. Raheela Farooq",  50,"35206-6789012-6","Family Law",   24,290,250,40,60000,"Pioneer of women's rights advocacy in Punjab with 24 years of family court experience."));
        // Property Law
        lawyers.add(new Lawyer("Adv. Asim Qureshi",    45,"35207-7890123-7","Property Law", 18,260,225,35,65000,"Expert in land disputes, property transfers and housing-society fraud cases."));
        lawyers.add(new Lawyer("Adv. Hina Baig",       39,"35208-8901234-8","Property Law", 13,175,148,27,50000,"Commercial property & real estate litigation across Lahore and Islamabad."));
        lawyers.add(new Lawyer("Adv. Fahad Raza",      52,"35209-9012345-9","Property Law", 25,340,295,45,80000,"Landmark cases involving government land acquisition."));
        // Corporate Law
        lawyers.add(new Lawyer("Adv. Zara Siddiqui",   36,"35210-0123456-1","Corporate Law",10,145,125,20,85000,"Advising startups, SMEs and multinationals on compliance and contracts."));
        lawyers.add(new Lawyer("Adv. Omar Cheema",     47,"35211-1234560-2","Corporate Law",20,280,245,35,95000,"Mergers, acquisitions and corporate governance. Former Fortune-500 legal counsel."));
        lawyers.add(new Lawyer("Adv. Ayesha Nawaz",    41,"35212-2345601-3","Corporate Law",15,200,172,28,75000,"Intellectual property, trademarks and corporate disputes."));
        // Civil Law
        lawyers.add(new Lawyer("Adv. Imran Javed",     44,"35213-3456012-4","Civil Law",    17,230,195,35,42000,"Civil suits, contract disputes and tort claims. Known for thorough research."));
        lawyers.add(new Lawyer("Adv. Samina Yousaf",   37,"35214-4560123-5","Civil Law",    11,160,138,22,35000,"Consumer protection and public interest litigation."));
        lawyers.add(new Lawyer("Adv. Rizwan Shah",     53,"35215-5601234-6","Civil Law",    26,380,330,50,70000,"Veteran civil lawyer with High Court and Supreme Court experience."));
        // Labour Law
        lawyers.add(new Lawyer("Adv. Khalid Mehmood",  46,"35216-6012345-7","Labour Law",   19,270,235,35,40000,"Wrongful termination, EOBI and workplace discrimination cases."));
        lawyers.add(new Lawyer("Adv. Fariha Malik",    33,"35217-7123456-8","Labour Law",    7, 95, 82,13,32000,"Factory workers and domestic helpers' rights."));
        lawyers.add(new Lawyer("Adv. Shahzad Hussain", 49,"35218-8234567-9","Labour Law",   21,300,258,42,55000,"Trade union representative in landmark legal battles."));
    }
}
