package lawbridge.ui;
import java.awt.*;

public class Theme {
    // Background shades — slightly brighter for better visibility
    public static final Color BG_DARKEST  = new Color(18,  11,  5);
    public static final Color BG_DARK     = new Color(30,  18,  8);
    public static final Color BG_MEDIUM   = new Color(48,  30, 12);
    public static final Color BG_LIGHT    = new Color(70,  44, 18);
    public static final Color BG_CARD     = new Color(40,  25, 10);
    public static final Color BG_HOVER    = new Color(85,  56, 22);

    // Gold & brown accents — more luminous
    public static final Color GOLD        = new Color(235, 195, 65);
    public static final Color GOLD_LIGHT  = new Color(255, 225, 120);
    public static final Color GOLD_BRIGHT = new Color(255, 240, 150);
    public static final Color BROWN_PRIMARY = new Color(160, 105, 50);
    public static final Color BROWN_ACCENT  = new Color(215, 165, 90);

    // Text — brighter & more legible
    public static final Color TEXT_WHITE     = new Color(255, 252, 242);
    public static final Color TEXT_PRIMARY   = new Color(248, 232, 205);
    public static final Color TEXT_SECONDARY = new Color(205, 170, 120);
    public static final Color TEXT_MUTED     = new Color(145, 110, 65);

    // Status
    public static final Color SUCCESS = new Color( 80, 215,  100);
    public static final Color ERROR   = new Color(235,  75,   75);
    public static final Color WARNING = new Color(255, 180,   30);
    public static final Color INFO    = new Color( 80, 175, 255);

    // Borders
    public static final Color BORDER      = new Color(80, 55, 22);
    public static final Color BORDER_GLOW = new Color(160, 110, 55);

    // Fonts
    public static final Font FONT_APPNAME = new Font("Georgia",     Font.BOLD,  30);
    public static final Font FONT_TITLE   = new Font("Georgia",     Font.BOLD,  24);
    public static final Font FONT_HEADING = new Font("Georgia",     Font.BOLD,  19);
    public static final Font FONT_SUBHEAD = new Font("Georgia",     Font.BOLD,  15);
    public static final Font FONT_BODY    = new Font("SansSerif",   Font.PLAIN, 13);
    public static final Font FONT_BODY_B  = new Font("SansSerif",   Font.BOLD,  13);
    public static final Font FONT_LABEL   = new Font("SansSerif",   Font.BOLD,  12);
    public static final Font FONT_SMALL   = new Font("SansSerif",   Font.PLAIN, 11);
    public static final Font FONT_SMALL_B = new Font("SansSerif",   Font.BOLD,  11);
    public static final Font FONT_NAV     = new Font("Georgia",     Font.BOLD,  14);
    public static final Font FONT_INPUT   = new Font("SansSerif",   Font.PLAIN, 13);
    public static final Font FONT_BUTTON  = new Font("Georgia",     Font.BOLD,  13);

    private Theme() {}
}
