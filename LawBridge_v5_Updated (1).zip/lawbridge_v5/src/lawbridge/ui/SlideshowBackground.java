package lawbridge.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

/**
 * Full-screen background that slowly crossfades between all law images
 * with floating particles, golden shimmer, and parallax glow effects.
 */
public class SlideshowBackground extends JPanel {

    private static final String[] IMAGE_NAMES = {
        "justice_statue.png", "law_books_gavel.png", "law_scales.png",
        "law_books.png", "scales_gavel.png"
    };

    private final BufferedImage[] images;
    private int currentIdx = 0;
    private float crossfade = 0f;      // 0=fully current, 1=fully next
    private float time = 0f;
    private float waveOffset = 0f;

    // Particles
    private static final int P = 24;
    private final float[] px = new float[P], py = new float[P];
    private final float[] pvx = new float[P], pvy = new float[P];
    private final float[] pr = new float[P], pa = new float[P];
    private final int[] ptype = new int[P];

    private final Timer timer;

    public SlideshowBackground() {
        setOpaque(false);
        images = new BufferedImage[IMAGE_NAMES.length];
        for (int i = 0; i < IMAGE_NAMES.length; i++) {
            try {
                var is = getClass().getResourceAsStream("/lawbridge/resources/" + IMAGE_NAMES[i]);
                if (is != null) images[i] = ImageIO.read(is);
            } catch (Exception ignored) {}
        }
        initParticles();
        timer = new Timer(30, e -> tick());
        timer.start();
    }

    private void initParticles() {
        for (int i = 0; i < P; i++) {
            px[i] = (float)(Math.random() * 1400);
            py[i] = (float)(Math.random() * 900);
            pvx[i] = (float)((Math.random() - 0.5) * 0.45);
            pvy[i] = (float)((Math.random() - 0.5) * 0.30);
            pr[i] = (float)(8 + Math.random() * 22);
            pa[i] = (float)(0.05 + Math.random() * 0.13);
            ptype[i] = (int)(Math.random() * 4);
        }
    }

    private void tick() {
        time += 0.025f;
        waveOffset += 0.6f;
        crossfade += 0.0015f;   // slow fade
        if (crossfade >= 1f) {
            crossfade = 0f;
            currentIdx = (currentIdx + 1) % images.length;
        }
        int W = Math.max(getWidth(), 1400), H = Math.max(getHeight(), 900);
        for (int i = 0; i < P; i++) {
            px[i] += pvx[i]; py[i] += pvy[i];
            if (px[i] < -60) px[i] = W + 50; if (px[i] > W + 60) px[i] = -50;
            if (py[i] < -60) py[i] = H + 50; if (py[i] > H + 60) py[i] = -50;
        }
        repaint();
    }

    public void stopAnimation() { timer.stop(); }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        int W = getWidth(), H = getHeight();

        // 1. Dark base
        g2.setColor(new Color(8, 4, 1));
        g2.fillRect(0, 0, W, H);

        // 2. Draw current image
        drawImage(g2, images[currentIdx], W, H, 0.68f);

        // 3. Crossfade next image
        int nextIdx = (currentIdx + 1) % images.length;
        if (crossfade > 0 && images[nextIdx] != null) {
            drawImage(g2, images[nextIdx], W, H, 0.68f * crossfade);
        }

        // 4. Dark overlay for readability
        g2.setComposite(AlphaComposite.SrcOver);
        g2.setColor(new Color(4, 2, 0, 120));
        g2.fillRect(0, 0, W, H);

        // 5. Vignette
        g2.setPaint(new RadialGradientPaint(W/2f, H/2f, Math.max(W, H)*0.65f,
            new float[]{0.3f, 1f},
            new Color[]{new Color(0,0,0,0), new Color(0,0,0,180)}));
        g2.fillRect(0, 0, W, H);

        // 6. Animated glow orbs
        float[][] orbPos = {{0.08f,0.12f},{0.88f,0.75f},{0.5f,0.04f},{0.15f,0.85f}};
        Color[] orbC = {new Color(139,90,43), new Color(212,175,55), new Color(100,60,20), new Color(180,130,40)};
        float[] orbR = {280, 240, 200, 220};
        for (int i = 0; i < 4; i++) {
            float pulse = (float)(Math.sin(time * 0.8 + i * 1.3) * 0.35 + 0.65);
            float r = orbR[i] * pulse;
            float cx = orbPos[i][0] * W, cy = orbPos[i][1] * H;
            Color c = orbC[i];
            g2.setPaint(new RadialGradientPaint(cx, cy, r,
                new float[]{0f, 1f},
                new Color[]{new Color(c.getRed(), c.getGreen(), c.getBlue(), (int)(22*pulse)), new Color(0,0,0,0)}));
            g2.fillOval((int)(cx-r),(int)(cy-r),(int)(r*2),(int)(r*2));
        }

        // 7. Diagonal grid
        g2.setComposite(AlphaComposite.SrcOver);
        g2.setColor(new Color(80, 55, 20, 7));
        g2.setStroke(new BasicStroke(1f));
        for (int x = -H; x < W+H; x += 65) g2.drawLine(x, 0, x+H, H);

        // 8. Floating law particles
        for (int i = 0; i < P; i++) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, pa[i]));
            g2.setColor(new Color(212, 175, 55));
            g2.setStroke(new BasicStroke(Math.max(1f, pr[i]/11f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            switch (ptype[i]) {
                case 0: drawScale(g2,(int)px[i],(int)py[i],(int)pr[i]); break;
                case 1: drawGavel(g2,(int)px[i],(int)py[i],(int)pr[i]); break;
                case 2: drawRing(g2,(int)px[i],(int)py[i],(int)pr[i]);  break;
                case 3: drawDiamond(g2,(int)px[i],(int)py[i],(int)pr[i]);break;
            }
        }
        g2.setComposite(AlphaComposite.SrcOver);

        // 9. Horizontal shimmer sweep
        float sweepY = (waveOffset % (H + 60)) - 30;
        g2.setPaint(new GradientPaint(0, sweepY-16, new Color(212,175,55,0), 0, sweepY, new Color(212,175,55,6)));
        g2.fillRect(0, (int)(sweepY-16), W, 32);

        // 10. Top gold shimmer bar
        g2.setPaint(new java.awt.LinearGradientPaint(0, 0, W, 0,
            new float[]{0f, 0.5f, 1f},
            new Color[]{new Color(212,175,55,0), new Color(212,175,55,80), new Color(212,175,55,0)}));
        g2.fillRect(0, 0, W, 2);

        g2.dispose();
        super.paintChildren(g);
    }

    private void drawImage(Graphics2D g2, BufferedImage img, int W, int H, float alpha) {
        if (img == null) return;
        float scale = Math.max((float)W/img.getWidth(), (float)H/img.getHeight());
        int iw = (int)(img.getWidth()*scale), ih = (int)(img.getHeight()*scale);
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
        g2.drawImage(img, (W-iw)/2, (H-ih)/2, iw, ih, null);
        g2.setComposite(AlphaComposite.SrcOver);
    }

    private void drawScale(Graphics2D g,int cx,int cy,int r){
        g.drawLine(cx-r,cy,cx+r,cy); g.drawLine(cx,cy-r,cx,cy+r/2);
        g.drawArc(cx-r-r/3,cy+r/4,r*2/3,r/3,0,-180);
        g.drawArc(cx+r-r/3,cy+r/4,r*2/3,r/3,0,-180);
    }
    private void drawGavel(Graphics2D g,int cx,int cy,int r){
        g.drawLine(cx-r/2,cy+r/2,cx+r/2,cy-r/2);
        g.drawRoundRect(cx-r/4-r*3/8,cy-r/4-r/6,r*3/4,r/3,4,4);
    }
    private void drawRing(Graphics2D g,int cx,int cy,int r){
        g.drawOval(cx-r,cy-r,r*2,r*2);
    }
    private void drawDiamond(Graphics2D g,int cx,int cy,int r){
        int[]xs={cx,cx+r,cx,cx-r}; int[]ys={cy-r,cy,cy+r,cy}; g.drawPolygon(xs,ys,4);
    }
}
