package lawbridge.ui;

import lawbridge.data.DataStore;
import lawbridge.models.User;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

public class LoginFrame extends JFrame {

    private JTextField     usernameField;
    private JPasswordField passwordField;
    private JLabel         statusLabel;

    public LoginFrame() {
        setTitle("LawBridge — Legal Portal");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(520, 700);
        setMinimumSize(new Dimension(420, 580));
        setResizable(true);
        setLocationRelativeTo(null);
        setUndecorated(true);

        SlideshowBackground root = new SlideshowBackground();
        root.setLayout(new BorderLayout());

        JPanel overlay = new JPanel(new BorderLayout());
        overlay.setOpaque(false);
        overlay.setBorder(BorderFactory.createLineBorder(new Color(235, 195, 65, 130), 1));

        overlay.add(buildDragBar(), BorderLayout.NORTH);
        overlay.add(buildForm(),    BorderLayout.CENTER);

        JLabel footer = new JLabel("Enter any username & password to create your account automatically", SwingConstants.CENTER);
        footer.setFont(Theme.FONT_SMALL);
        footer.setForeground(new Color(160, 125, 65));
        footer.setBorder(BorderFactory.createEmptyBorder(0, 0, 18, 0));
        overlay.add(footer, BorderLayout.SOUTH);

        root.add(overlay, BorderLayout.CENTER);
        setContentPane(root);
        makeDraggable(buildDragBar());
    }

    private JPanel buildDragBar() {
        JPanel bar = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(12, 6, 2, 230));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setPaint(new GradientPaint(0, getHeight()-1,
                    new Color(235,195,65,0), getWidth()*0.5f, getHeight()-1, new Color(235,195,65,110)));
                g2.drawLine(0, getHeight()-1, getWidth(), getHeight()-1);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        bar.setOpaque(false);
        bar.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        // Professional inline logo in drag bar
        JPanel barLogo = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
            }
        };
        barLogo.setOpaque(false);

        JPanel miniLogo = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                drawProfessionalLogo(g2, 0, 0, 22);
                g2.dispose();
            }
        };
        miniLogo.setOpaque(false);
        miniLogo.setPreferredSize(new Dimension(26, 26));

        JLabel titleLbl = new JLabel("LawBridge — Legal Portal");
        titleLbl.setFont(new Font("Georgia", Font.BOLD, 13));
        titleLbl.setForeground(Theme.GOLD);

        barLogo.add(miniLogo);
        barLogo.add(titleLbl);
        bar.add(barLogo, BorderLayout.WEST);

        JButton close = new JButton("✕");
        close.setFont(new Font("SansSerif", Font.PLAIN, 14));
        close.setForeground(new Color(170, 130, 70));
        close.setContentAreaFilled(false);
        close.setBorderPainted(false);
        close.setFocusPainted(false);
        close.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        close.addMouseListener(new MouseAdapter(){
            public void mouseEntered(MouseEvent e){ close.setForeground(Theme.ERROR); }
            public void mouseExited (MouseEvent e){ close.setForeground(new Color(170,130,70)); }
        });
        close.addActionListener(e -> System.exit(0));
        bar.add(close, BorderLayout.EAST);
        makeDraggable(bar);
        return bar;
    }

    /** Draws a professional justice-scales gavel logo using pure Graphics2D */
    private void drawProfessionalLogo(Graphics2D g2, int ox, int oy, int size) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int cx = ox + size/2, cy = oy + size/2;

        // Outer glow ring
        g2.setColor(new Color(235,195,65, 60));
        g2.fillOval(ox, oy, size, size);

        // Dark fill
        g2.setColor(new Color(18, 10, 3));
        g2.fillOval(ox+2, oy+2, size-4, size-4);

        // Gold ring
        g2.setColor(Theme.GOLD);
        g2.setStroke(new BasicStroke(1.8f));
        g2.drawOval(ox+2, oy+2, size-4, size-4);

        // Justice pillar (center stem)
        int stemW = Math.max(2, size/10);
        g2.setColor(Theme.GOLD_LIGHT);
        g2.fillRect(cx - stemW/2, cy - size/3 + 2, stemW, size/2);

        // Top cross-beam of scales
        int beamY = cy - size/4 + 2;
        int beamHalf = size/3 - 2;
        g2.setStroke(new BasicStroke(Math.max(1.2f, size/18f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.drawLine(cx - beamHalf, beamY, cx + beamHalf, beamY);

        // Left scale pan chain
        int panW = size/4;
        g2.drawLine(cx - beamHalf + panW/2, beamY, cx - beamHalf + panW/2, beamY + size/5);
        // Left pan
        g2.drawArc(cx - beamHalf, beamY + size/5, panW, size/9, 0, -180);

        // Right scale pan chain
        g2.drawLine(cx + beamHalf - panW/2, beamY, cx + beamHalf - panW/2, beamY + size/5);
        // Right pan
        g2.drawArc(cx + beamHalf - panW, beamY + size/5, panW, size/9, 0, -180);

        // Base
        int baseY = cy + size/4;
        g2.setStroke(new BasicStroke(Math.max(1.5f, size/14f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.drawLine(cx - size/4, baseY, cx + size/4, baseY);
    }

    private JPanel buildForm() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);

        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(28, 60, 20, 60));

        // ── Professional Animated Logo ──
        JPanel logoCircle = new JPanel() {
            float pulse = 0, rotate = 0;
            Timer t = new Timer(30, e -> { pulse += 0.045f; rotate += 0.010f; repaint(); });
            { t.start(); setOpaque(false); setPreferredSize(new Dimension(110, 110)); setMaximumSize(new Dimension(110, 110)); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                float glow = (float)(Math.sin(pulse) * 0.4 + 0.6);
                int cx = getWidth()/2, cy = getHeight()/2;

                // Outer rotating dashed ring
                g2.rotate(rotate, cx, cy);
                g2.setColor(new Color(235, 195, 65, (int)(60 * glow)));
                g2.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 0, new float[]{7, 5}, 0));
                g2.drawOval(3, 3, getWidth()-6, getHeight()-6);
                g2.rotate(-rotate, cx, cy);

                // Second slower counter-rotating ring
                g2.rotate(-rotate * 0.5, cx, cy);
                g2.setColor(new Color(235, 195, 65, (int)(30 * glow)));
                g2.setStroke(new BasicStroke(1f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 0, new float[]{3, 8}, 0));
                g2.drawOval(8, 8, getWidth()-16, getHeight()-16);
                g2.rotate(rotate * 0.5, cx, cy);

                // Glow halo
                g2.setColor(new Color(235, 195, 65, (int)(50 * glow)));
                g2.fillOval(cx-44, cy-44, 88, 88);

                // Dark circle fill
                g2.setColor(new Color(18, 10, 3));
                g2.fillOval(cx-38, cy-38, 76, 76);

                // Solid gold ring
                g2.setColor(new Color(235, 195, 65, (int)(235 * glow)));
                g2.setStroke(new BasicStroke(2.5f));
                g2.drawOval(cx-38, cy-38, 76, 76);

                // Professional scales logo inside
                drawProfessionalLogo(g2, cx-28, cy-28, 56);
                g2.dispose();
            }
        };
        logoCircle.setAlignmentX(Component.CENTER_ALIGNMENT);

        // App name with shimmer
        JLabel appName = new JLabel("LawBridge") {
            float t = 0;
            Timer tm = new Timer(45, e -> { t += 0.03f; repaint(); });
            { tm.start(); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
                float shimmer = (float)(Math.sin(t) * 0.5 + 0.5);
                g2.setPaint(new GradientPaint(
                    0, 0, new Color(255, 240, 150),
                    getWidth() * shimmer, getHeight(), new Color(190, 145, 50)));
                g2.setFont(getFont());
                g2.drawString(getText(), 0, g2.getFontMetrics().getAscent());
                g2.dispose();
            }
        };
        appName.setFont(new Font("Georgia", Font.BOLD, 32));
        appName.setForeground(Theme.GOLD);
        appName.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel tagline = UIComponents.makeLabel("Your Trusted Legal Companion", Theme.FONT_BODY, new Color(180, 140, 75));
        tagline.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Animated separator
        JPanel sep = new JPanel() {
            float t = 0;
            Timer tm = new Timer(40, e -> { t += 0.04f; repaint(); });
            { tm.start(); setOpaque(false); setPreferredSize(new Dimension(300, 4)); setMaximumSize(new Dimension(Integer.MAX_VALUE, 4)); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                float center = (float)(Math.sin(t) * 0.1 + 0.5);
                g2.setPaint(new java.awt.LinearGradientPaint(0, 0, getWidth(), 0,
                    new float[]{0f, center, 1f},
                    new Color[]{new Color(235,195,65,0), new Color(235,195,65,220), new Color(235,195,65,0)}));
                g2.fillRoundRect(0, 0, getWidth(), 2, 2, 2);
                g2.dispose();
            }
        };
        sep.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel uLbl = buildFieldLabel("USERNAME");
        JLabel pLbl = buildFieldLabel("PASSWORD");

        usernameField = UIComponents.makeTextField(22);
        usernameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        usernameField.setFont(new Font("SansSerif", Font.BOLD, 14));

        passwordField = UIComponents.makePasswordField(22);
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        passwordField.setFont(new Font("SansSerif", Font.BOLD, 14));
        passwordField.addKeyListener(new KeyAdapter(){
            public void keyPressed(KeyEvent e){ if(e.getKeyCode()==KeyEvent.VK_ENTER) doLogin(); }
        });

        // Sign-in button
        JButton loginBtn = new JButton("  Sign In  /  Create Account  ") {
            boolean hov = false;
            { addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){ hov=true; repaint(); }
                public void mouseExited(MouseEvent e){ hov=false; repaint(); }
            });
            setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));}
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (hov) {
                    g2.setPaint(new GradientPaint(0, 0, new Color(255, 215, 75), 0, getHeight(), new Color(200, 155, 40)));
                } else {
                    g2.setPaint(new GradientPaint(0, 0, new Color(235,195,65), 0, getHeight(), new Color(175,135,35)));
                }
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                if (hov) {
                    g2.setColor(new Color(255, 245, 180, 100));
                    g2.setStroke(new BasicStroke(2f));
                    g2.drawRoundRect(1, 1, getWidth()-2, getHeight()-2, 12, 12);
                }
                g2.setColor(new Color(20, 12, 4));
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                String s = getText().trim();
                g2.drawString(s, (getWidth()-fm.stringWidth(s))/2, (getHeight()-fm.getHeight())/2+fm.getAscent());
                g2.dispose();
            }
        };
        loginBtn.setFont(new Font("Georgia", Font.BOLD, 15));
        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginBtn.setPreferredSize(new Dimension(340, 50));
        loginBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        loginBtn.addActionListener(e -> doLogin());

        statusLabel = UIComponents.makeLabel(" ", Theme.FONT_SMALL, Theme.ERROR);
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        p.add(logoCircle);
        p.add(Box.createVerticalStrut(16));
        p.add(appName);
        p.add(Box.createVerticalStrut(6));
        p.add(tagline);
        p.add(Box.createVerticalStrut(22));
        p.add(sep);
        p.add(Box.createVerticalStrut(24));
        p.add(uLbl);
        p.add(Box.createVerticalStrut(7));
        p.add(usernameField);
        p.add(Box.createVerticalStrut(18));
        p.add(pLbl);
        p.add(Box.createVerticalStrut(7));
        p.add(passwordField);
        p.add(Box.createVerticalStrut(28));
        p.add(loginBtn);
        p.add(Box.createVerticalStrut(14));
        p.add(statusLabel);

        wrapper.add(p, BorderLayout.CENTER);
        return wrapper;
    }

    private JLabel buildFieldLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 11));
        lbl.setForeground(new Color(185, 145, 70));
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }

    private void doLogin() {
        String user = usernameField.getText().trim();
        String pass = new String(passwordField.getPassword()).trim();
        if (user.isEmpty() || pass.isEmpty()) {
            show("Please enter both username and password.", Theme.WARNING);
            return;
        }
        User u = DataStore.getInstance().authenticate(user, pass);
        if (u != null) {
            show("Welcome, " + u.getUsername() + "!  Opening LawBridge...", Theme.SUCCESS);
            Timer t = new Timer(700, ev -> { dispose(); new MainFrame(u).setVisible(true); });
            t.setRepeats(false); t.start();
        } else {
            show("Wrong password for existing account. Try again.", Theme.ERROR);
            passwordField.setText("");
        }
    }

    private void show(String msg, Color color) {
        statusLabel.setText(msg);
        statusLabel.setForeground(color);
    }

    private Point drag;
    private void makeDraggable(JPanel bar) {
        bar.addMouseListener(new MouseAdapter(){
            public void mousePressed(MouseEvent e){ drag = e.getPoint(); }
        });
        bar.addMouseMotionListener(new MouseMotionAdapter(){
            public void mouseDragged(MouseEvent e){
                Point loc = getLocationOnScreen();
                setLocation(loc.x+e.getX()-drag.x, loc.y+e.getY()-drag.y);
            }
        });
    }
}
