package lawbridge.ui;

import lawbridge.data.DataStore;
import lawbridge.models.Lawyer;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

public class LawyersPanel extends JPanel {

    private final DataStore ds = DataStore.getInstance();
    private JPanel grid;
    private JComboBox<String> filterCombo;

    // Predefined free slot pool per lawyer (keyed by name)
    private static final Map<String, String[]> SLOT_MAP = new LinkedHashMap<>();
    static {
        String[][] names = {
            {"Adv. Kamran Hussain",  "Mon 09:00 AM", "Mon 11:00 AM", "Wed 02:00 PM", "Fri 10:00 AM"},
            {"Adv. Sana Mirza",      "Tue 10:00 AM", "Thu 03:00 PM", "Fri 09:00 AM"},
            {"Adv. Tariq Mahmood",   "Mon 02:00 PM", "Wed 10:00 AM", "Fri 04:00 PM"},
            {"Adv. Nadia Akhtar",    "Tue 11:00 AM", "Thu 09:00 AM", "Sat 10:00 AM"},
            {"Adv. Bilal Chaudhry",  "Mon 03:00 PM", "Wed 11:00 AM", "Fri 02:00 PM"},
            {"Adv. Raheela Farooq",  "Tue 09:00 AM", "Thu 01:00 PM", "Sat 11:00 AM"},
            {"Adv. Asim Qureshi",    "Mon 10:00 AM", "Wed 03:00 PM", "Fri 11:00 AM"},
            {"Adv. Hina Baig",       "Tue 02:00 PM", "Thu 10:00 AM", "Sat 09:00 AM"},
            {"Adv. Fahad Raza",      "Mon 11:00 AM", "Wed 09:00 AM", "Fri 03:00 PM"},
            {"Adv. Zara Siddiqui",   "Tue 03:00 PM", "Thu 11:00 AM", "Sat 02:00 PM"},
            {"Adv. Omar Cheema",     "Mon 04:00 PM", "Wed 01:00 PM", "Fri 09:00 AM"},
            {"Adv. Ayesha Nawaz",    "Tue 01:00 PM", "Thu 04:00 PM", "Sat 03:00 PM"},
            {"Adv. Imran Javed",     "Mon 09:00 AM", "Wed 04:00 PM", "Fri 01:00 PM"},
            {"Adv. Samina Yousaf",   "Tue 04:00 PM", "Thu 02:00 PM", "Sat 01:00 PM"},
            {"Adv. Rizwan Shah",     "Mon 01:00 PM", "Wed 02:00 PM", "Fri 04:00 PM"},
            {"Adv. Khalid Mehmood",  "Tue 09:00 AM", "Thu 03:00 PM", "Sat 04:00 PM"},
            {"Adv. Fariha Malik",    "Mon 03:00 PM", "Wed 10:00 AM", "Fri 02:00 PM"},
            {"Adv. Shahzad Hussain", "Tue 11:00 AM", "Thu 09:00 AM", "Sat 10:00 AM"},
        };
        for (String[] row : names) {
            String lawyerName = row[0];
            String[] slots = java.util.Arrays.copyOfRange(row, 1, row.length);
            SLOT_MAP.put(lawyerName, slots);
        }
    }

    public LawyersPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.BG_DARK);

        add(buildHeader(),  BorderLayout.NORTH);

        // Animated background
        ImageBackground animBg = new ImageBackground(ImageBackground.ImageType.JUSTICE_STATUE);
        animBg.setLayout(new BorderLayout());

        JPanel body = new JPanel(new BorderLayout());
        body.setOpaque(false);
        body.setBorder(BorderFactory.createEmptyBorder(16,26,22,26));
        body.add(buildFilter(), BorderLayout.NORTH);

        grid = new JPanel();
        grid.setLayout(new BoxLayout(grid, BoxLayout.Y_AXIS));
        grid.setOpaque(false);

        JScrollPane sp = new JScrollPane(grid);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.setBorder(null);
        sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        sp.getVerticalScrollBar().setUnitIncrement(20);
        sp.getVerticalScrollBar().setPreferredSize(new Dimension(6, 0));
        sp.getVerticalScrollBar().setUI(new javax.swing.plaf.basic.BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() {
                thumbColor = new Color(212,175,55,90);
                trackColor = new Color(30,18,7,80);
            }
            @Override protected JButton createDecreaseButton(int o) {
                JButton b=new JButton(); b.setPreferredSize(new Dimension(0,0)); return b; }
            @Override protected JButton createIncreaseButton(int o) {
                JButton b=new JButton(); b.setPreferredSize(new Dimension(0,0)); return b; }
        });
        body.add(sp, BorderLayout.CENTER);

        animBg.add(body, BorderLayout.CENTER);
        add(animBg, BorderLayout.CENTER);

        addHierarchyListener(e -> {
            if ((e.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0 && !isShowing())
                animBg.stopAnimation();
        });
        loadLawyers("All");
    }

    private JPanel buildHeader() {
        JPanel h = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                GradientPaint gp=new GradientPaint(0,0,Theme.BG_MEDIUM,getWidth(),0,Theme.BG_DARK);
                g2.setPaint(gp); g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(Theme.BORDER);
                g2.drawLine(0,getHeight()-1,getWidth(),getHeight()-1);
                g2.dispose();
            }
        };
        h.setPreferredSize(new Dimension(0,74));
        h.setLayout(new FlowLayout(FlowLayout.LEFT,28,18));
        h.add(UIComponents.makeLabel("👨‍⚖️", new Font("SansSerif",Font.PLAIN,26),Theme.GOLD));
        h.add(UIComponents.makeLabel("Our Expert Lawyers", new Font("Georgia",Font.BOLD,21),Theme.TEXT_WHITE));
        h.add(UIComponents.makeLabel("  18 qualified legal professionals ready to assist you.",
                new Font("SansSerif",Font.PLAIN,13),Theme.TEXT_SECONDARY));
        return h;
    }

    private JPanel buildFilter() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(0,0,14,0));
        p.add(UIComponents.makeLabel("Filter by Specialization:", new Font("SansSerif",Font.BOLD,13),Theme.TEXT_SECONDARY));
        String[] specs={"All","Criminal Law","Family Law","Property Law","Corporate Law","Civil Law","Labour Law"};
        filterCombo = UIComponents.makeComboBox(specs);
        filterCombo.setPreferredSize(new Dimension(240,36));
        filterCombo.addActionListener(e -> loadLawyers((String)filterCombo.getSelectedItem()));
        p.add(filterCombo);
        return p;
    }

    private void loadLawyers(String filter) {
        grid.removeAll();

        List<Lawyer> lawyers = ("All".equals(filter) || filter==null)
            ? ds.getAllLawyers()
            : ds.getLawyersBySpecialization(filter);

        // Group by specialization
        Map<String,List<Lawyer>> groups = new LinkedHashMap<>();
        for (Lawyer l : lawyers) {
            groups.computeIfAbsent(l.getSpecialization(), k -> new ArrayList<>()).add(l);
        }

        for (Map.Entry<String,List<Lawyer>> e : groups.entrySet()) {
            // Section header
            JLabel hdr = UIComponents.makeLabel("[" + e.getKey() + "]",
                    new Font("Georgia",Font.BOLD,16), Theme.GOLD_LIGHT);
            hdr.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0,0,1,0,Theme.BORDER),
                BorderFactory.createEmptyBorder(6,0,8,0)));
            hdr.setMaximumSize(new Dimension(Integer.MAX_VALUE,36));
            grid.add(hdr);
            grid.add(Box.createVerticalStrut(10));

            // Lawyers in rows of 3
            List<Lawyer> grp = e.getValue();
            int cols = 3;
            for (int r = 0; r < grp.size(); r += cols) {
                JPanel row = new JPanel(new GridLayout(1, cols, 14, 0));
                row.setOpaque(false);
                row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 280));
                for (int c = 0; c < cols; c++) {
                    int idx = r + c;
                    if (idx < grp.size()) row.add(lawyerCard(grp.get(idx)));
                    else { JPanel ph = new JPanel(); ph.setOpaque(false); row.add(ph); }
                }
                grid.add(row);
                grid.add(Box.createVerticalStrut(12));
            }
            grid.add(Box.createVerticalStrut(8));
        }
        grid.revalidate();
        grid.repaint();
    }

    private JPanel lawyerCard(Lawyer l) {
        JPanel card = new JPanel() {
            boolean hov;
            { addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){hov=true; repaint();}
                public void mouseExited (MouseEvent e){hov=false;repaint();}
            });}
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(hov ? Theme.BG_HOVER : Theme.BG_CARD);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),14,14);
                g2.setColor(hov ? Theme.GOLD : Theme.BORDER);
                g2.setStroke(new BasicStroke(1.4f));
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,14,14);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setLayout(new BoxLayout(card,BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(18,20,18,20));

        // Avatar
        String ini = initials(l.getName());
        JLabel av = new JLabel(ini) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Theme.BG_LIGHT);  g2.fillOval(0,0,getWidth(),getHeight());
                g2.setColor(Theme.GOLD); g2.setStroke(new BasicStroke(2f));
                g2.drawOval(1,1,getWidth()-2,getHeight()-2);
                super.paintComponent(g);
                g2.dispose();
            }
        };
        av.setFont(new Font("Georgia",Font.BOLD,17));
        av.setForeground(Theme.GOLD_LIGHT);
        av.setHorizontalAlignment(SwingConstants.CENTER);
        av.setPreferredSize(new Dimension(58,58));
        av.setMaximumSize(new Dimension(58,58));
        av.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel name = UIComponents.makeLabel(l.getName(), new Font("Georgia",Font.BOLD,15), Theme.TEXT_WHITE);
        name.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel spec = UIComponents.makeLabel(l.getSpecialization(), new Font("SansSerif",Font.BOLD,12), Theme.GOLD);
        spec.setAlignmentX(Component.CENTER_ALIGNMENT);

        JSeparator sep = new JSeparator();
        sep.setForeground(Theme.BORDER);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE,1));

        // 3-col stats
        JPanel stats = new JPanel(new GridLayout(1,3,6,0));
        stats.setOpaque(false);
        stats.setMaximumSize(new Dimension(Integer.MAX_VALUE,56));
        stats.add(statCol(l.getYearsOfExperience()+" yr","Exp"));
        stats.add(statCol(String.valueOf(l.getCasesSolved()),"Cases"));
        stats.add(statCol(l.getWins()+"W / "+l.getLosses()+"L","Record"));

        JLabel fees = UIComponents.makeLabel("Rs. "+(int)l.getFees()+" / case",
                new Font("Georgia",Font.BOLD,15),Theme.GOLD_LIGHT);
        fees.setAlignmentX(Component.CENTER_ALIGNMENT);

        // ── Book Appointment Button ──────────────────────────────────────────
        JButton bookBtn = new JButton("📅  Book Appointment") {
            boolean hov;
            { setOpaque(false); setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
              setCursor(new Cursor(Cursor.HAND_CURSOR));
              addMouseListener(new MouseAdapter(){
                  public void mouseEntered(MouseEvent e){hov=true; repaint();}
                  public void mouseExited (MouseEvent e){hov=false;repaint();}
              });
            }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = hov ? Theme.GOLD : new Color(180,140,30);
                g2.setColor(bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                super.paintComponent(g);
                g2.dispose();
            }
        };
        bookBtn.setFont(new Font("SansSerif",Font.BOLD,13));
        bookBtn.setForeground(Theme.BG_DARK);
        bookBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        bookBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        bookBtn.addActionListener(e -> showSlotDialog(l));
        // ────────────────────────────────────────────────────────────────────

        card.add(av);
        card.add(Box.createVerticalStrut(8));
        card.add(name);
        card.add(Box.createVerticalStrut(2));
        card.add(spec);
        card.add(Box.createVerticalStrut(10));
        card.add(sep);
        card.add(Box.createVerticalStrut(10));
        card.add(stats);
        card.add(Box.createVerticalStrut(8));
        card.add(fees);
        card.add(Box.createVerticalStrut(12));
        card.add(bookBtn);
        return card;
    }

    // ── Appointment slot dialog ───────────────────────────────────────────────
    private void showSlotDialog(Lawyer l) {
        String[] slots = SLOT_MAP.getOrDefault(l.getName(), new String[]{"No slots available this week"});

        // Dark-themed dialog
        JDialog dlg = new JDialog(SwingUtilities.getWindowAncestor(this), "Book Appointment", Dialog.ModalityType.APPLICATION_MODAL);
        dlg.setUndecorated(true);
        dlg.setSize(420, 360);
        dlg.setLocationRelativeTo(this);

        JPanel root = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Theme.BG_CARD);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),18,18);
                g2.setColor(Theme.GOLD);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,18,18);
                g2.dispose();
            }
        };
        root.setOpaque(false);
        root.setBorder(BorderFactory.createEmptyBorder(22,24,22,24));

        // ── Header ──
        JPanel hdr = new JPanel();
        hdr.setLayout(new BoxLayout(hdr, BoxLayout.Y_AXIS));
        hdr.setOpaque(false);

        JLabel title = UIComponents.makeLabel("📅  Available Slots", new Font("Georgia",Font.BOLD,17), Theme.GOLD);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub = UIComponents.makeLabel(l.getName(), new Font("SansSerif",Font.BOLD,13), Theme.TEXT_WHITE);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel fee = UIComponents.makeLabel("Consultation Fee: Rs. "+(int)l.getFees(), new Font("SansSerif",Font.PLAIN,12), Theme.TEXT_SECONDARY);
        fee.setAlignmentX(Component.CENTER_ALIGNMENT);

        hdr.add(title);
        hdr.add(Box.createVerticalStrut(4));
        hdr.add(sub);
        hdr.add(Box.createVerticalStrut(2));
        hdr.add(fee);
        hdr.add(Box.createVerticalStrut(14));

        JSeparator sep2 = new JSeparator();
        sep2.setForeground(Theme.BORDER);
        hdr.add(sep2);
        hdr.add(Box.createVerticalStrut(14));

        root.add(hdr, BorderLayout.NORTH);

        // ── Slot buttons ──
        JPanel slotsPanel = new JPanel();
        slotsPanel.setLayout(new BoxLayout(slotsPanel, BoxLayout.Y_AXIS));
        slotsPanel.setOpaque(false);

        ButtonGroup bg = new ButtonGroup();
        JToggleButton[] toggles = new JToggleButton[slots.length];
        for (int i = 0; i < slots.length; i++) {
            final String slot = slots[i];
            JToggleButton tb = new JToggleButton("🕐  " + slot) {
                boolean hov;
                { setOpaque(false); setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
                  setCursor(new Cursor(Cursor.HAND_CURSOR));
                  addMouseListener(new MouseAdapter(){
                      public void mouseEntered(MouseEvent e){hov=true; repaint();}
                      public void mouseExited (MouseEvent e){hov=false;repaint();}
                  });
                }
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    boolean sel = isSelected();
                    g2.setColor(sel ? new Color(180,140,30,200) : (hov ? Theme.BG_HOVER : Theme.BG_MEDIUM));
                    g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                    g2.setColor(sel ? Theme.GOLD : Theme.BORDER);
                    g2.setStroke(new BasicStroke(sel ? 1.8f : 1f));
                    g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,10,10);
                    super.paintComponent(g);
                    g2.dispose();
                }
            };
            tb.setFont(new Font("SansSerif", Font.PLAIN, 13));
            tb.setForeground(Theme.TEXT_WHITE);
            tb.setHorizontalAlignment(SwingConstants.LEFT);
            tb.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            tb.setAlignmentX(Component.CENTER_ALIGNMENT);
            bg.add(tb);
            toggles[i] = tb;
            slotsPanel.add(tb);
            slotsPanel.add(Box.createVerticalStrut(8));
        }
        root.add(slotsPanel, BorderLayout.CENTER);

        // ── Confirm + Cancel ──
        JPanel btnRow = new JPanel(new GridLayout(1,2,12,0));
        btnRow.setOpaque(false);
        btnRow.setBorder(BorderFactory.createEmptyBorder(14,0,0,0));

        JButton cancel = styledBtn("Cancel", Theme.BG_MEDIUM, Theme.TEXT_SECONDARY);
        cancel.addActionListener(e -> dlg.dispose());

        JButton confirm = styledBtn("Confirm Booking", new Color(180,140,30), Theme.BG_DARK);
        confirm.addActionListener(e -> {
            String chosen = null;
            for (JToggleButton tb : toggles) if (tb.isSelected()) { chosen = tb.getText().replace("🕐  ",""); break; }
            if (chosen == null) {
                JOptionPane.showMessageDialog(dlg, "Please select a time slot first.", "No Slot Selected", JOptionPane.WARNING_MESSAGE);
                return;
            }
            dlg.dispose();
            JOptionPane.showMessageDialog(
                LawyersPanel.this,
                "<html><b style='color:#D4AF37'>Appointment Confirmed!</b><br><br>"
                + "Lawyer: " + l.getName() + "<br>"
                + "Slot: " + chosen + "<br>"
                + "Fee: Rs. " + (int)l.getFees() + "<br><br>"
                + "<i>You will receive a confirmation shortly.</i></html>",
                "Booking Successful", JOptionPane.INFORMATION_MESSAGE);
        });

        btnRow.add(cancel);
        btnRow.add(confirm);
        root.add(btnRow, BorderLayout.SOUTH);

        dlg.setContentPane(root);
        dlg.setVisible(true);
    }

    private JButton styledBtn(String text, Color bg, Color fg) {
        return new JButton(text) {
            boolean hov;
            { setOpaque(false); setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
              setCursor(new Cursor(Cursor.HAND_CURSOR));
              addMouseListener(new MouseAdapter(){
                  public void mouseEntered(MouseEvent e){hov=true; repaint();}
                  public void mouseExited (MouseEvent e){hov=false;repaint();}
              });
            }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(hov ? bg.brighter() : bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                super.paintComponent(g);
                g2.dispose();
            }
            { setFont(new Font("SansSerif",Font.BOLD,13)); setForeground(fg); setPreferredSize(new Dimension(0,40)); }
        };
    }

    private JPanel statCol(String val, String lbl) {
        JPanel p=new JPanel(); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS)); p.setOpaque(false);
        JLabel v=UIComponents.makeLabel(val,new Font("Georgia",Font.BOLD,14),Theme.BROWN_ACCENT);
        JLabel l=UIComponents.makeLabel(lbl,new Font("SansSerif",Font.BOLD,11),Theme.TEXT_MUTED);
        v.setAlignmentX(Component.CENTER_ALIGNMENT);
        l.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(v); p.add(l);
        return p;
    }

    private String initials(String name) {
        String[] p = name.split("\\s+");
        int s = p[0].equals("Adv.") ? 1 : 0;
        return (s+1<p.length)
            ? (""+p[s].charAt(0)+p[s+1].charAt(0)).toUpperCase()
            : name.substring(0,Math.min(2,name.length())).toUpperCase();
    }
}
