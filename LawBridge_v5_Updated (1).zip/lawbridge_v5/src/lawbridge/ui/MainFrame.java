package lawbridge.ui;

import lawbridge.models.User;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class MainFrame extends JFrame {

    private User loggedInUser;
    private JPanel contentArea;
    private JButton[] navButtons;

    // Nav items: {label, icon-char drawn via g2, index}
    // We avoid emoji, use Unicode symbols that render via AWT font
    private static final String[] NAV_LABELS = {"Home", "Booked Appointments", "Lawyers", "About"};
    // Use simple drawn icons instead of emoji
    private static final int[]    NAV_INDICES = {0, 1, 2, 3};

    public MainFrame(User user) {
        this.loggedInUser = user;
        setTitle("LawBridge — Legal Advocacy Platform");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1280, 780);
        setMinimumSize(new Dimension(1050, 640));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Theme.BG_DARKEST);

        root.add(buildTopBar(),  BorderLayout.NORTH);
        root.add(buildSidebar(), BorderLayout.WEST);

        contentArea = new JPanel(new BorderLayout());
        contentArea.setBackground(Theme.BG_DARK);
        root.add(contentArea, BorderLayout.CENTER);

        setContentPane(root);
        navigateTo(0);
    }

    // ═══════════════════════════════════════════════════════════════
    //  TOP BAR
    // ═══════════════════════════════════════════════════════════════
    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0,0, new Color(8, 4, 1, 245),
                        getWidth(),0, new Color(22, 12, 3, 245));
                g2.setPaint(gp);
                g2.fillRect(0,0,getWidth(),getHeight());
                // Double gold bottom lines for premium look
                g2.setPaint(new java.awt.LinearGradientPaint(0,0,getWidth(),0,
                    new float[]{0f,0.3f,0.7f,1f},
                    new Color[]{new Color(212,175,55,0), Theme.GOLD,
                                Theme.GOLD, new Color(212,175,55,0)}));
                g2.setStroke(new BasicStroke(2f));
                g2.drawLine(0, getHeight()-1, getWidth(), getHeight()-1);
                g2.setColor(new Color(212,175,55,30));
                g2.drawLine(0, getHeight()-3, getWidth(), getHeight()-3);
                g2.dispose();
            }
        };
        bar.setPreferredSize(new Dimension(0, 64));
        bar.setOpaque(false);
        bar.setBorder(BorderFactory.createEmptyBorder(0, 16, 0, 16));

        // LEFT: Logo
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        left.setOpaque(false);
        left.setPreferredSize(new Dimension(210, 64));

        // Draw professional logo as custom panel
        JPanel logoPanel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                // Professional scales of justice logo
                drawProfessionalLogo(g2, 8, 14, 34);
                // Text
                g2.setFont(new Font("Georgia", Font.BOLD, 18));
                g2.setColor(Theme.GOLD);
                g2.drawString("LawBridge", 50, 26);
                g2.setFont(new Font("SansSerif", Font.PLAIN, 10));
                g2.setColor(Theme.TEXT_SECONDARY);
                g2.drawString("Legal Advocacy Platform", 50, 42);
                g2.dispose();
            }
        };
        logoPanel.setOpaque(false);
        logoPanel.setPreferredSize(new Dimension(208, 64));

        left.add(logoPanel);

        // CENTER: Page title
        JLabel pageTitle = new JLabel("Welcome to LawBridge", SwingConstants.CENTER);
        pageTitle.setFont(new Font("Georgia", Font.BOLD, 21));
        pageTitle.setForeground(Theme.TEXT_WHITE);
        pageTitle.setHorizontalAlignment(SwingConstants.CENTER);

        // RIGHT: Profile card + logout
        JPanel right = buildProfileBar();

        bar.add(left,      BorderLayout.WEST);
        bar.add(pageTitle, BorderLayout.CENTER);
        bar.add(right,     BorderLayout.EAST);
        return bar;
    }

    // ── Attractive profile bar ────────────────────────────────────
    private JPanel buildProfileBar() {
        JPanel outer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        outer.setOpaque(false);
        outer.setPreferredSize(new Dimension(290, 64));

        // Glass card behind profile info
        JPanel card = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(40,24,8,180));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                g2.setColor(new Color(212,175,55,60));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,12,12);
                g2.dispose();super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(200, 44));

        // Avatar circle — drawn, no emoji
        JPanel avatar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                // Gold ring glow
                g2.setColor(new Color(212,175,55,50));
                g2.fillOval(0,0,getWidth(),getHeight());
                g2.setColor(new Color(55,34,14));
                g2.fillOval(2,2,getWidth()-4,getHeight()-4);
                g2.setColor(Theme.GOLD);
                g2.setStroke(new BasicStroke(1.8f));
                g2.drawOval(2,2,getWidth()-4,getHeight()-4);
                // Initials text
                String ini = loggedInUser.getInitials();
                g2.setFont(new Font("Georgia",Font.BOLD,13));
                g2.setColor(Theme.GOLD_LIGHT);
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(ini,(getWidth()-fm.stringWidth(ini))/2,
                        (getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        avatar.setOpaque(false);
        avatar.setPreferredSize(new Dimension(34,34));

        JPanel textStack = new JPanel();
        textStack.setLayout(new BoxLayout(textStack,BoxLayout.Y_AXIS));
        textStack.setOpaque(false);
        JLabel uName = UIComponents.makeLabel(loggedInUser.getUsername(),
                new Font("Georgia",Font.BOLD,13),Theme.TEXT_WHITE);
        JLabel uEmail= UIComponents.makeLabel(loggedInUser.getEmail(),
                new Font("SansSerif",Font.PLAIN,10),Theme.TEXT_MUTED);
        textStack.add(uName); textStack.add(uEmail);

        card.add(avatar);
        card.add(textStack);

        // Logout button — text-based, no emoji
        JButton logout = new JButton("Logout") {
            boolean h;
            { addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){h=true;repaint();}
                public void mouseExited (MouseEvent e){h=false;repaint();}
              });
              setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
              setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = h ? new Color(180,40,40) : new Color(120,30,30);
                g2.setColor(bg); g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                g2.setColor(h ? new Color(255,180,180) : new Color(255,120,120));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,8,8);
                g2.setFont(new Font("Georgia",Font.BOLD,12));
                g2.setColor(Color.WHITE);
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,
                        (getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        logout.setFont(new Font("Georgia",Font.BOLD,12));
        logout.setPreferredSize(new Dimension(70,34));
        logout.addActionListener(e -> {
            int ok = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?","Logout",JOptionPane.YES_NO_OPTION);
            if(ok==JOptionPane.YES_OPTION){ dispose(); new LoginFrame().setVisible(true); }
        });

        outer.add(card);
        outer.add(logout);
        return outer;
    }

    // ═══════════════════════════════════════════════════════════════
    //  SIDEBAR — thin (170px), custom-drawn icons, no emoji
    // ═══════════════════════════════════════════════════════════════
    private JPanel buildSidebar() {
        JPanel sb = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                GradientPaint gp=new GradientPaint(0,0,new Color(6,3,1,252),
                        getWidth(),0,new Color(14,8,3,252));
                g2.setPaint(gp); g2.fillRect(0,0,getWidth(),getHeight());
                // Right border — double line for depth
                g2.setColor(new Color(212,175,55,80));
                g2.drawLine(getWidth()-1,0,getWidth()-1,getHeight());
                g2.setColor(new Color(212,175,55,25));
                g2.drawLine(getWidth()-2,0,getWidth()-2,getHeight());
                g2.dispose();
            }
        };
        sb.setPreferredSize(new Dimension(200, 0));
        sb.setLayout(new BoxLayout(sb, BoxLayout.Y_AXIS));
        sb.setBorder(BorderFactory.createEmptyBorder(24,0,20,0));

        navButtons = new JButton[NAV_LABELS.length];
        for (int i = 0; i < NAV_LABELS.length; i++) {
            final int idx = i;
            JButton btn = makeNavBtn(i);
            btn.addActionListener(e -> navigateTo(idx));
            navButtons[i] = btn;
            sb.add(btn);
            sb.add(Box.createVerticalStrut(2));
        }

        sb.add(Box.createVerticalGlue());

        // Footer — plain text version string
        JLabel ver = UIComponents.makeLabel("v 1.0  LawBridge", 
                new Font("SansSerif",Font.PLAIN,9), Theme.TEXT_MUTED);
        ver.setBorder(BorderFactory.createEmptyBorder(0,14,0,0));
        ver.setAlignmentX(Component.LEFT_ALIGNMENT);
        sb.add(ver);
        return sb;
    }

    private JButton makeNavBtn(int navIdx) {
        // Icon painters for each nav item (no emoji)
        JButton btn = new JButton() {
            boolean hov = false;
            { putClientProperty("sel", false);
              addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){hov=true; repaint();}
                public void mouseExited (MouseEvent e){hov=false;repaint();}
              });
              setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
              setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                boolean sel = Boolean.TRUE.equals(getClientProperty("sel"));

                if (sel) {
                    // Selected: gold left bar + highlight bg
                    g2.setColor(Theme.GOLD);
                    g2.fillRoundRect(0,8,4,getHeight()-16,4,4);
                    GradientPaint bg=new GradientPaint(4,0,new Color(80,52,16,180),getWidth(),0,new Color(40,24,8,60));
                    g2.setPaint(bg); g2.fillRect(4,0,getWidth()-4,getHeight());
                } else if (hov) {
                    g2.setColor(new Color(212,175,55,25));
                    g2.fillRect(0,0,getWidth(),getHeight());
                }

                // Draw icon (custom drawn)
                int iconX = 18, iconY = getHeight()/2;
                g2.setColor(sel ? Theme.GOLD_LIGHT : (hov ? Theme.GOLD : new Color(160,120,70)));
                g2.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                drawNavIcon(g2, navIdx, iconX, iconY, 11);

                // Label
                g2.setFont(new Font("Georgia", Font.BOLD, 12));
                g2.setColor(sel ? Theme.GOLD_LIGHT : (hov ? Theme.TEXT_WHITE : new Color(180,140,85)));
                g2.drawString(NAV_LABELS[navIdx], 42, iconY + 5);
                g2.dispose();
            }
        };
        btn.setPreferredSize(new Dimension(200, 46));
        btn.setMaximumSize(new Dimension(200, 46));
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        return btn;
    }

    /** Draw nav icons using Graphics2D — zero emoji dependency */
    private void drawNavIcon(Graphics2D g2, int idx, int cx, int cy, int r) {
        switch(idx) {
            case 0: // Home — house shape
                int[] hx = {cx, cx-r, cx-r, cx+r, cx+r};
                int[] hy = {cy-r, cy-2, cy+r, cy+r, cy-2};
                g2.drawPolygon(hx, hy, 5);
                g2.drawRect(cx-4, cy+1, 8, r-1);
                break;
            case 1: // Case — clipboard
                g2.drawRoundRect(cx-r, cy-r, r*2, r*2, 4,4);
                g2.drawLine(cx-r+4, cy-3, cx+r-4, cy-3);
                g2.drawLine(cx-r+4, cy+3, cx+r-4, cy+3);
                g2.drawRect(cx-4, cy-r-2, 8, 5);
                break;
            case 2: // Lawyers — person with collar (judge)
                g2.drawOval(cx-5, cy-r, 10, 10);
                g2.drawArc(cx-r, cy-2, r*2, r+4, 0, -180);
                g2.drawLine(cx-3, cy+2, cx, cy+r);
                g2.drawLine(cx+3, cy+2, cx, cy+r);
                break;
            case 3: // About — info circle with i
                g2.drawOval(cx-r, cy-r, r*2, r*2);
                g2.setFont(new Font("Georgia", Font.BOLD, r+3));
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString("i", cx - fm.stringWidth("i")/2, cy + fm.getAscent()/2 - 2);
                break;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  NAVIGATION
    // ═══════════════════════════════════════════════════════════════
    public void navigateTo(int idx) {
        for (int i = 0; i < navButtons.length; i++) {
            navButtons[i].putClientProperty("sel", i == idx);
            navButtons[i].repaint();
        }
        JPanel panel;
        switch (idx) {
            case 1: panel = new CasePanel(loggedInUser); break;
            case 2: panel = new LawyersPanel();          break;
            case 3: panel = new AboutPanel();            break;
            default: panel = new HomePanel(this);
        }
        showPanel(panel);
    }

    public void showPanel(JPanel panel) {
        contentArea.removeAll();
        contentArea.add(panel, BorderLayout.CENTER);
        contentArea.revalidate();
        contentArea.repaint();
    }

    public User getLoggedInUser() { return loggedInUser; }

    /** Professional scales-of-justice logo drawn with Graphics2D */
    private void drawProfessionalLogo(Graphics2D g2, int ox, int oy, int size) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int cx = ox + size/2, cy = oy + size/2;

        // Glow halo
        g2.setColor(new Color(235,195,65, 55));
        g2.fillOval(ox, oy, size, size);
        // Dark fill
        g2.setColor(new Color(18, 10, 3));
        g2.fillOval(ox+2, oy+2, size-4, size-4);
        // Gold ring
        g2.setColor(Theme.GOLD);
        g2.setStroke(new BasicStroke(1.8f));
        g2.drawOval(ox+2, oy+2, size-4, size-4);

        // Central pillar
        int stemW = Math.max(2, size/10);
        g2.setColor(Theme.GOLD_LIGHT);
        g2.fillRect(cx - stemW/2, cy - size/3 + 2, stemW, size/2);

        // Top cross-beam
        int beamY = cy - size/4 + 2;
        int beamHalf = size/3 - 2;
        g2.setColor(Theme.GOLD);
        g2.setStroke(new BasicStroke(Math.max(1.2f, size/18f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.drawLine(cx - beamHalf, beamY, cx + beamHalf, beamY);

        // Left pan
        int panW = size/4;
        g2.drawLine(cx - beamHalf + panW/2, beamY, cx - beamHalf + panW/2, beamY + size/5);
        g2.drawArc(cx - beamHalf, beamY + size/5, panW, size/9, 0, -180);

        // Right pan
        g2.drawLine(cx + beamHalf - panW/2, beamY, cx + beamHalf - panW/2, beamY + size/5);
        g2.drawArc(cx + beamHalf - panW, beamY + size/5, panW, size/9, 0, -180);

        // Base
        int baseY = cy + size/4;
        g2.setStroke(new BasicStroke(Math.max(1.5f, size/14f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.drawLine(cx - size/4, baseY, cx + size/4, baseY);
    }
}
