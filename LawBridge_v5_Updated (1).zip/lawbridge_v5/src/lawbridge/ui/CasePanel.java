package lawbridge.ui;

import lawbridge.data.DataStore;
import lawbridge.models.Client;
import lawbridge.models.Lawyer;
import lawbridge.models.User;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class CasePanel extends JPanel {

    private final User user;
    private final DataStore ds = DataStore.getInstance();

    // Fields
    private JTextField nameF, ageF, cnicF, bFormF, fatherF, motherF, fatherCnicF, siblingsF, phoneF;
    private JComboBox<String> caseCombo, lawyerCombo;
    private JTextArea detailsArea;
    private JLabel feesLbl, lawyerBioLbl;
    private List<Lawyer> curLawyers;

    public CasePanel(User user) {
        this.user = user;
        setLayout(new BorderLayout());
        setBackground(Theme.BG_DARK);
        add(buildHeader(), BorderLayout.NORTH);

        JPanel form = buildForm();
        ImageBackground imgBg = new ImageBackground(ImageBackground.ImageType.LAW_BOOKS);
        imgBg.setLayout(new BorderLayout());
        JScrollPane sp = new JScrollPane(form);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.setBorder(null);
        sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        sp.getVerticalScrollBar().setUnitIncrement(18);
        sp.getVerticalScrollBar().setPreferredSize(new Dimension(5,0));
        sp.getVerticalScrollBar().setUI(new javax.swing.plaf.basic.BasicScrollBarUI(){
            @Override protected void configureScrollBarColors(){thumbColor=new Color(212,175,55,100);trackColor=new Color(20,12,4,60);}
            @Override protected JButton createDecreaseButton(int o){JButton b=new JButton();b.setPreferredSize(new Dimension(0,0));return b;}
            @Override protected JButton createIncreaseButton(int o){JButton b=new JButton();b.setPreferredSize(new Dimension(0,0));return b;}
        });
        imgBg.add(sp, BorderLayout.CENTER);
        add(imgBg, BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel h = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                GradientPaint gp=new GradientPaint(0,0,Theme.BG_MEDIUM,getWidth(),0,Theme.BG_DARK);
                g2.setPaint(gp); g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(Theme.BORDER); g2.drawLine(0,getHeight()-1,getWidth(),getHeight()-1);
                g2.dispose();
            }
        };
        h.setPreferredSize(new Dimension(0,74));
        h.setLayout(new FlowLayout(FlowLayout.LEFT,28,18));
        h.add(UIComponents.makeLabel("[C]",new Font("SansSerif",Font.PLAIN,26),Theme.GOLD));
        h.add(UIComponents.makeLabel("Booked Appointments",new Font("Georgia",Font.BOLD,21),Theme.TEXT_WHITE));
        h.add(UIComponents.makeLabel("  Manage and review your scheduled legal consultations.",
                new Font("SansSerif",Font.PLAIN,13),Theme.TEXT_SECONDARY));
        return h;
    }

    private JPanel buildForm() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(22,28,28,28));

        p.add(sec("Personal Information"));
        p.add(Box.createVerticalStrut(10));
        p.add(personalSection());
        p.add(Box.createVerticalStrut(20));

        p.add(sec("👨‍👩‍👧   Family Information"));
        p.add(Box.createVerticalStrut(10));
        p.add(familySection());
        p.add(Box.createVerticalStrut(20));

        p.add(sec("Case Details"));
        p.add(Box.createVerticalStrut(10));
        p.add(caseSection());
        p.add(Box.createVerticalStrut(20));

        p.add(sec("Choose Your Lawyer"));
        p.add(Box.createVerticalStrut(10));
        p.add(lawyerSection());
        p.add(Box.createVerticalStrut(28));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnRow.setOpaque(false);
        JButton sub = UIComponents.makePrimaryButton("  ✅   Submit My Case  ");
        sub.setFont(new Font("Georgia",Font.BOLD,15));
        sub.addActionListener(e -> doSubmit());
        btnRow.add(sub);
        p.add(btnRow);
        return p;
    }

    private JLabel sec(String t) {
        JLabel l = UIComponents.makeLabel(t, new Font("Georgia",Font.BOLD,17), Theme.GOLD_LIGHT);
        l.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0,0,1,0,Theme.BORDER),
            BorderFactory.createEmptyBorder(0,0,8,0)));
        l.setMaximumSize(new Dimension(Integer.MAX_VALUE,38));
        return l;
    }

    private JPanel personalSection() {
        JPanel card = formCard();
        nameF     = tf(); ageF  = tf(); cnicF  = tf();
        bFormF    = tf(); phoneF= tf();
        addRow(card,0,"Full Name *",    nameF, "Age *",          ageF);
        addRow(card,1,"CNIC (13 digits)*",cnicF,"B-Form No.",   bFormF);
        addRow(card,2,"Phone Number *", phoneF,null,            null);
        return card;
    }

    private JPanel familySection() {
        JPanel card = formCard();
        fatherF=tf(); motherF=tf(); fatherCnicF=tf(); siblingsF=tf();
        addRow(card,0,"Father's Name *",fatherF,"Mother's Name",motherF);
        addRow(card,1,"Father's CNIC",  fatherCnicF,"No. of Siblings",siblingsF);
        return card;
    }

    private JPanel caseSection() {
        JPanel card = formCard();
        GridBagConstraints c = gbc();

        caseCombo = UIComponents.makeComboBox(ds.getCaseTypes());
        caseCombo.addActionListener(e -> onCaseChanged());

        detailsArea = UIComponents.makeTextArea(5,40);
        detailsArea.setBackground(Theme.BG_MEDIUM);
        JScrollPane taSP = new JScrollPane(detailsArea);
        taSP.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        taSP.getViewport().setBackground(Theme.BG_MEDIUM);
        taSP.setPreferredSize(new Dimension(0,100));

        c.gridx=0;c.gridy=0;c.weightx=0.25; card.add(lbl("Case Type *"),c);
        c.gridx=1;c.gridy=0;c.weightx=0.75;c.gridwidth=3; card.add(caseCombo,c); c.gridwidth=1;
        c.gridx=0;c.gridy=1;c.weightx=0.25; card.add(lbl("Case Details *"),c);
        c.gridx=1;c.gridy=1;c.weightx=0.75;c.gridwidth=3; card.add(taSP,c);
        return card;
    }

    private JPanel lawyerSection() {
        JPanel card = formCard();
        GridBagConstraints c = gbc();

        lawyerCombo = UIComponents.makeComboBox(new String[]{"Please select a case type first..."});
        lawyerCombo.addActionListener(e -> onLawyerChanged());

        feesLbl    = UIComponents.makeLabel("—", new Font("Georgia",Font.BOLD,15), Theme.GOLD);
        lawyerBioLbl = UIComponents.makeLabel(
            "<html><body style='width:520px;color:#907050'>Select a case type, then choose a lawyer to view their profile.</body></html>",
            Theme.FONT_SMALL, Theme.TEXT_MUTED);
        lawyerBioLbl.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.BORDER),
            BorderFactory.createEmptyBorder(8,10,8,10)));

        c.gridx=0;c.gridy=0;c.weightx=0.25; card.add(lbl("Select Lawyer *"),c);
        c.gridx=1;c.gridy=0;c.weightx=0.75;c.gridwidth=3; card.add(lawyerCombo,c); c.gridwidth=1;
        c.gridx=0;c.gridy=1;c.weightx=0.25; card.add(lbl("Consultation Fee"),c);
        c.gridx=1;c.gridy=1;c.weightx=0.75;c.gridwidth=3; card.add(feesLbl,c); c.gridwidth=1;
        c.gridx=0;c.gridy=2;c.weightx=0.25; card.add(lbl("Lawyer Profile"),c);
        c.gridx=1;c.gridy=2;c.weightx=0.75;c.gridwidth=3; card.add(lawyerBioLbl,c);
        return card;
    }

    // ── helpers ────────────────────────────────────────────────────
    private JPanel formCard() {
        JPanel c = UIComponents.makeCard();
        c.setLayout(new GridBagLayout());
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE,220));
        return c;
    }

    private JTextField tf() {
        JTextField f = UIComponents.makeTextField(18);
        f.setFont(new Font("SansSerif",Font.BOLD,13));
        return f;
    }

    private JLabel lbl(String t) {
        return UIComponents.makeLabel(t, new Font("SansSerif",Font.BOLD,12), Theme.TEXT_SECONDARY);
    }

    private GridBagConstraints gbc() {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(7,8,7,8);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.WEST;
        return c;
    }

    private void addRow(JPanel card, int row, String l1, JComponent f1, String l2, JComponent f2) {
        GridBagConstraints c = gbc();
        c.gridx=0; c.gridy=row; c.weightx=0.22; card.add(lbl(l1),c);
        c.gridx=1; c.gridy=row; c.weightx=0.28; card.add(f1,c);
        if (l2!=null && f2!=null) {
            c.gridx=2; c.gridy=row; c.weightx=0.22; card.add(lbl(l2),c);
            c.gridx=3; c.gridy=row; c.weightx=0.28; card.add(f2,c);
        }
    }

    private void onCaseChanged() {
        String sel = (String) caseCombo.getSelectedItem();
        if (sel==null || sel.startsWith("Select")) {
            lawyerCombo.setModel(new DefaultComboBoxModel<>(new String[]{"Please select a case type first..."}));
            curLawyers = null; feesLbl.setText("—"); return;
        }
        String spec = ds.getSpecializationForCase(sel);
        curLawyers = (spec!=null) ? ds.getLawyersBySpecialization(spec) : ds.getAllLawyers();
        String[] opts = new String[curLawyers.size()];
        for (int i=0;i<curLawyers.size();i++) opts[i]=curLawyers.get(i).getDisplayName();
        lawyerCombo.setModel(new DefaultComboBoxModel<>(opts));
        onLawyerChanged();
    }

    private void onLawyerChanged() {
        int i = lawyerCombo.getSelectedIndex();
        if (curLawyers!=null && i>=0 && i<curLawyers.size()) {
            Lawyer l = curLawyers.get(i);
            feesLbl.setText("Rs. "+(int)l.getFees()+" per case");
            lawyerBioLbl.setText(
                "<html><body style='width:520px;color:#BCA070;font-size:12px'>"
                +"<b>"+l.getName()+"</b> | "+l.getSpecialization()
                +" | Experience: <b>"+l.getYearsOfExperience()+" years</b>"
                +" | Cases: <b>"+l.getCasesSolved()+"</b>"
                +" | Wins: <b>"+l.getWins()+"</b>"
                +" | Losses: <b>"+l.getLosses()+"</b><br>"
                +"<i>"+l.getDescription()+"</i></body></html>");
        }
    }

    private void doSubmit() {
        if (nameF.getText().trim().isEmpty())    { err("Please enter your full name.");    return; }
        if (ageF.getText().trim().isEmpty())     { err("Please enter your age.");          return; }
        if (cnicF.getText().trim().isEmpty())    { err("Please enter your CNIC.");         return; }
        if (fatherF.getText().trim().isEmpty())  { err("Please enter your father's name.");return; }
        if (phoneF.getText().trim().isEmpty())   { err("Please enter your phone number."); return; }
        if (caseCombo.getSelectedIndex()==0)     { err("Please select a case type.");      return; }
        if (detailsArea.getText().trim().isEmpty()){ err("Please enter case details.");    return; }
        if (curLawyers==null || lawyerCombo.getSelectedIndex()<0){ err("Please select a lawyer."); return; }

        try {
            Client cl = new Client(nameF.getText().trim(),
                Integer.parseInt(ageF.getText().trim()),
                cnicF.getText().trim());
            cl.setBForm(bFormF.getText().trim());
            cl.setFatherName(fatherF.getText().trim());
            cl.setMotherName(motherF.getText().trim());
            cl.setFatherCnic(fatherCnicF.getText().trim());
            cl.setNumberOfSiblings(siblingsF.getText().isEmpty()?0:Integer.parseInt(siblingsF.getText().trim()));
            cl.setPhoneNumber(phoneF.getText().trim());
            cl.setCaseType((String)caseCombo.getSelectedItem());
            cl.setCaseDetails(detailsArea.getText().trim());
            Lawyer law = curLawyers.get(lawyerCombo.getSelectedIndex());
            cl.setSelectedLawyer(law.getName());
            showSuccess(cl, law);
        } catch (NumberFormatException ex) {
            err("Please enter valid numbers for Age and Siblings.");
        }
    }

    private void showSuccess(Client cl, Lawyer law) {
        JDialog dlg = new JDialog();
        dlg.setTitle("Case Submitted");
        dlg.setSize(500,400);
        dlg.setLocationRelativeTo(this);
        dlg.setModal(true);

        JPanel p = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setColor(Theme.BG_DARK); g2.fillRect(0,0,getWidth(),getHeight());
                g2.dispose();
            }
        };
        p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(30,40,30,40));

        JLabel tick = UIComponents.makeLabel("✅",new Font("SansSerif",Font.PLAIN,56),Theme.SUCCESS);
        tick.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel m1 = UIComponents.makeLabel("Your Response Has Been Saved!",
                new Font("Georgia",Font.BOLD,20),Theme.TEXT_WHITE);
        m1.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel m2 = UIComponents.makeLabel("Our lawyer will contact you soon.",
                new Font("SansSerif",Font.PLAIN,14),Theme.TEXT_SECONDARY);
        m2.setAlignmentX(Component.CENTER_ALIGNMENT);

        JSeparator sep=new JSeparator(); sep.setForeground(Theme.BORDER);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE,1));

        JLabel info = UIComponents.makeLabel(
            "<html><body style='text-align:center;font-size:13px;color:#C8A070'>"
            +"Client: <b>"+cl.getName()+"</b><br>"
            +"Case: <b>"+cl.getCaseType()+"</b><br>"
            +"Assigned Lawyer: <b>"+law.getName()+"</b><br>"
            +"Consultation Fee: <b>Rs. "+(int)law.getFees()+"</b><br>"
            +"Contact: <b>"+cl.getPhoneNumber()+"</b>"
            +"</body></html>",Theme.FONT_BODY,Theme.TEXT_SECONDARY);
        info.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton ok = UIComponents.makePrimaryButton("  Done  ");
        ok.setAlignmentX(Component.CENTER_ALIGNMENT);
        ok.addActionListener(e->{ dlg.dispose(); clearForm(); });

        p.add(tick); p.add(Box.createVerticalStrut(8));
        p.add(m1);   p.add(Box.createVerticalStrut(4));
        p.add(m2);   p.add(Box.createVerticalStrut(14));
        p.add(sep);  p.add(Box.createVerticalStrut(12));
        p.add(info); p.add(Box.createVerticalStrut(20));
        p.add(ok);

        dlg.setContentPane(p);
        dlg.setVisible(true);
    }

    private void clearForm() {
        nameF.setText("");ageF.setText("");cnicF.setText("");bFormF.setText("");
        fatherF.setText("");motherF.setText("");fatherCnicF.setText("");
        siblingsF.setText("");phoneF.setText("");
        caseCombo.setSelectedIndex(0); detailsArea.setText("");
        lawyerCombo.setModel(new DefaultComboBoxModel<>(new String[]{"Please select a case type first..."}));
        feesLbl.setText("—"); curLawyers=null;
    }

    private void err(String msg) {
        JOptionPane.showMessageDialog(this,msg,"Missing Information",JOptionPane.WARNING_MESSAGE);
    }
}
