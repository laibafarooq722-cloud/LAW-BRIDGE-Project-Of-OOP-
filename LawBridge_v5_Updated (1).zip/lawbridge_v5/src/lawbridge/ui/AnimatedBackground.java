package lawbridge.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.InputStream;

/**
 * Animated background with actual law images, floating particles, and glow effects.
 */
public class AnimatedBackground extends JPanel {

    private static final int PARTICLE_COUNT = 18;
    private final float[] px  = new float[PARTICLE_COUNT];
    private final float[] py  = new float[PARTICLE_COUNT];
    private final float[] pvx = new float[PARTICLE_COUNT];
    private final float[] pvy = new float[PARTICLE_COUNT];
    private final float[] pr  = new float[PARTICLE_COUNT];
    private final float[] pa  = new float[PARTICLE_COUNT];
    private final int[]   ptype= new int[PARTICLE_COUNT];

    private static final int ORB_COUNT = 3;
    private final float[] opulse = new float[ORB_COUNT];
    private final float[] ospeed = new float[ORB_COUNT];

    private float waveOffset = 0;
    private final Timer timer;

    // Background images (loaded once)
    private static BufferedImage[] bgImages;
    private static boolean imagesLoaded = false;
    private int bgImageIndex = 0; // which image this instance uses

    public AnimatedBackground() {
        this(0);
    }

    public AnimatedBackground(int imageIndex) {
        this.bgImageIndex = imageIndex;
        setOpaque(false);
        loadImages();
        initParticles();
        initOrbs();
        timer = new Timer(30, e -> { waveOffset += 0.7f; moveParticles(); repaint(); });
        timer.start();
    }

    private static synchronized void loadImages() {
        if (imagesLoaded) return;
        String[] names = {"justice_statue.png", "law_books_gavel.png", "scales_gavel.png"};
        bgImages = new BufferedImage[names.length];
        for (int i = 0; i < names.length; i++) {
            try {
                InputStream is = AnimatedBackground.class
                    .getResourceAsStream("/lawbridge/resources/" + names[i]);
                if (is != null) bgImages[i] = ImageIO.read(is);
            } catch (Exception e) { /* silently skip */ }
        }
        imagesLoaded = true;
    }

    public void stopAnimation() { timer.stop(); }

    private void initParticles() {
        for (int i = 0; i < PARTICLE_COUNT; i++) {
            px[i]   = (float)(Math.random() * 1400);
            py[i]   = (float)(Math.random() * 900);
            pvx[i]  = (float)((Math.random()-0.5)*0.5);
            pvy[i]  = (float)((Math.random()-0.5)*0.35);
            pr[i]   = (float)(7 + Math.random()*20);
            pa[i]   = (float)(0.06 + Math.random()*0.14);
            ptype[i]= (int)(Math.random()*4);
        }
    }

    private void initOrbs() {
        float[][] pos = {{0.1f,0.15f},{0.85f,0.7f},{0.5f,0.05f}};
        for (int i = 0; i < ORB_COUNT; i++) {
            opulse[i] = (float)(Math.random()*Math.PI*2);
            ospeed[i] = (float)(0.010+Math.random()*0.015);
        }
    }

    private void moveParticles() {
        int w = Math.max(getWidth(),1400), h = Math.max(getHeight(),900);
        for (int i = 0; i < PARTICLE_COUNT; i++) {
            px[i]+=pvx[i]; py[i]+=pvy[i];
            if(px[i]<-60) px[i]=w+50; if(px[i]>w+60) px[i]=-50;
            if(py[i]<-60) py[i]=h+50; if(py[i]>h+60) py[i]=-50;
        }
        for (int i = 0; i < ORB_COUNT; i++) opulse[i]+=ospeed[i];
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D)g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,  RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING,     RenderingHints.VALUE_RENDER_QUALITY);
        int W = getWidth(), H = getHeight();

        // 1. Solid dark base
        g2.setColor(new Color(14,8,3));
        g2.fillRect(0,0,W,H);

        // 2. Draw blended background image
        if (bgImages != null && bgImageIndex < bgImages.length && bgImages[bgImageIndex] != null) {
            BufferedImage img = bgImages[bgImageIndex];
            // Scale to cover
            float scale = Math.max((float)W/img.getWidth(), (float)H/img.getHeight());
            int iw = (int)(img.getWidth()*scale), ih = (int)(img.getHeight()*scale);
            int ix = (W-iw)/2, iy = (H-ih)/2;
            // Draw with heavy dark overlay to keep it subtle
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.10f));
            g2.drawImage(img, ix, iy, iw, ih, null);
            g2.setComposite(AlphaComposite.SrcOver);
        }

        // 3. Radial dark overlay so image fades to dark edges
        RadialGradientPaint radial = new RadialGradientPaint(
            W/2f, H/2f, Math.max(W,H)*0.65f,
            new float[]{0f, 0.6f, 1f},
            new Color[]{new Color(14,8,3,60), new Color(14,8,3,140), new Color(14,8,3,220)}
        );
        g2.setPaint(radial); g2.fillRect(0,0,W,H);

        // 4. Glow orbs
        float[][] orbPos = {{0.1f,0.15f},{0.85f,0.7f},{0.5f,0.05f}};
        float[] orbR = {300,250,200};
        Color[] orbC = {new Color(139,90,43), new Color(212,175,55), new Color(100,60,20)};
        for (int i = 0; i < ORB_COUNT; i++) {
            float pulse=(float)(Math.sin(opulse[i])*0.35+0.65);
            float r=orbR[i]*pulse;
            float cx=orbPos[i][0]*W, cy=orbPos[i][1]*H;
            Color c=new Color(orbC[i].getRed(),orbC[i].getGreen(),orbC[i].getBlue(),(int)(20*pulse));
            RadialGradientPaint rg=new RadialGradientPaint(cx,cy,r,new float[]{0f,1f},
                new Color[]{c,new Color(0,0,0,0)});
            g2.setPaint(rg); g2.fillOval((int)(cx-r),(int)(cy-r),(int)(r*2),(int)(r*2));
        }

        // 5. Subtle diagonal grid
        g2.setColor(new Color(80,55,20,6));
        g2.setStroke(new BasicStroke(1f));
        for (int x=-H; x<W+H; x+=70) g2.drawLine(x,0,x+H,H);

        // 6. Floating legal particles
        for (int i = 0; i < PARTICLE_COUNT; i++) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,pa[i]));
            g2.setColor(new Color(212,175,55));
            g2.setStroke(new BasicStroke(Math.max(1,pr[i]/12f)));
            switch(ptype[i]) {
                case 0: drawScale(g2,(int)px[i],(int)py[i],(int)pr[i]); break;
                case 1: drawGavel(g2,(int)px[i],(int)py[i],(int)pr[i]); break;
                case 2: drawRing(g2,(int)px[i],(int)py[i],(int)pr[i]);  break;
                case 3: drawDiamond(g2,(int)px[i],(int)py[i],(int)pr[i]);break;
            }
        }
        g2.setComposite(AlphaComposite.SrcOver);

        // 7. Sweep shimmer
        float sweepY=(waveOffset%(H+60))-30;
        g2.setPaint(new GradientPaint(0,sweepY-16,new Color(212,175,55,0),0,sweepY,new Color(212,175,55,5)));
        g2.fillRect(0,(int)(sweepY-16),W,32);

        // 8. Vignette
        g2.setPaint(new RadialGradientPaint(W/2f,H/2f,Math.max(W,H)*0.7f,
            new float[]{0.35f,1f},new Color[]{new Color(0,0,0,0),new Color(0,0,0,140)}));
        g2.fillRect(0,0,W,H);

        g2.dispose();
    }

    private void drawScale(Graphics2D g,int cx,int cy,int r){
        g.drawLine(cx-r,cy,cx+r,cy); g.drawLine(cx,cy-r,cx,cy+r/2);
        g.drawArc(cx-r-r/3,cy+r/4,r*2/3,r/3,0,-180);
        g.drawArc(cx+r-r/3,cy+r/4,r*2/3,r/3,0,-180);
        g.drawLine(cx-r,cy,cx-r-r/6,cy+r/4); g.drawLine(cx-r,cy,cx-r+r/6,cy+r/4);
        g.drawLine(cx+r,cy,cx+r-r/6,cy+r/4); g.drawLine(cx+r,cy,cx+r+r/6,cy+r/4);
    }
    private void drawGavel(Graphics2D g,int cx,int cy,int r){
        g.drawLine(cx-r/2,cy+r/2,cx+r/2,cy-r/2);
        g.drawRoundRect(cx-r/4-r*3/8,cy-r/4-r/6,r*3/4,r/3,4,4);
    }
    private void drawRing(Graphics2D g,int cx,int cy,int r){
        g.drawOval(cx-r,cy-r,r*2,r*2); g.drawOval(cx-r*3/4,cy-r*3/4,r*3/2,r*3/2);
    }
    private void drawDiamond(Graphics2D g,int cx,int cy,int r){
        int[]xs={cx,cx+r,cx,cx-r}; int[]ys={cy-r,cy,cy+r,cy}; g.drawPolygon(xs,ys,4);
    }
}
