package lawbridge.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 * A background panel that shows one of the uploaded legal images,
 * heavily darkened + blurred so UI content stays readable.
 * Falls back to AnimatedBackground if image load fails.
 */
public class ImageBackground extends JPanel {

    public enum ImageType { SCALES_GAVEL, LAW_BOOKS, JUSTICE_STATUE }

    private BufferedImage bg;
    private BufferedImage bgScaled; // cached scaled version for sharpness
    private int cachedW = -1, cachedH = -1;
    private final AnimatedBackground fallback;

    // IMAGE VISIBILITY: 0.0=invisible, 1.0=full colour.
    // 0.72 gives a rich, sharp background that stays readable under text.
    private static final float IMAGE_ALPHA  = 0.72f;
    // Dark tint layer on top so white text always pops.
    private static final int   TINT_ALPHA   = 115; // 0-255

    public ImageBackground(ImageType type) {
        setOpaque(false);
        fallback = new AnimatedBackground();

        String res;
        switch(type) {
            case LAW_BOOKS:      res = "law_books_gavel.png"; break;
            case JUSTICE_STATUE: res = "justice_statue.png";  break;
            default:             res = "law_scales.png";      break;
        }
        try {
            BufferedImage raw = ImageIO.read(
                getClass().getResourceAsStream("/lawbridge/resources/" + res));
            // Convert to TYPE_INT_ARGB for best quality compositing
            if (raw != null) {
                bg = new BufferedImage(raw.getWidth(), raw.getHeight(),
                        BufferedImage.TYPE_INT_ARGB);
                Graphics2D cvt = bg.createGraphics();
                cvt.setRenderingHint(RenderingHints.KEY_RENDERING,
                        RenderingHints.VALUE_RENDER_QUALITY);
                cvt.drawImage(raw, 0, 0, null);
                cvt.dispose();
            }
        } catch (Exception e) {
            bg = null;
        }
    }

    /** Pre-renders a high-quality scaled copy whenever the panel is resized. */
    private BufferedImage getScaled(int W, int H) {
        if (bg == null) return null;
        if (bgScaled != null && cachedW == W && cachedH == H) return bgScaled;
        double imgW = bg.getWidth(), imgH = bg.getHeight();
        double scale = Math.max(W / imgW, H / imgH);
        int dW = (int)(imgW * scale);
        int dH = (int)(imgH * scale);
        bgScaled = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Graphics2D sg = bgScaled.createGraphics();
        sg.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        sg.setRenderingHint(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);
        sg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        sg.drawImage(bg, (W - dW) / 2, (H - dH) / 2, dW, dH, null);
        sg.dispose();
        cachedW = W; cachedH = H;
        return bgScaled;
    }

    public void stopAnimation() { fallback.stopAnimation(); }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        int W = getWidth(), H = getHeight();

        // 1. Solid base — prevents flicker
        g2.setColor(new Color(10, 6, 2));
        g2.fillRect(0, 0, W, H);

        BufferedImage scaled = getScaled(W, H);
        if (scaled != null) {
            // 2. Draw sharp, pre-scaled image at full vivid colour
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, IMAGE_ALPHA));
            g2.drawImage(scaled, 0, 0, null);
            g2.setComposite(AlphaComposite.SrcOver);

            // 3. Lightweight dark tint — just enough for text legibility, not a blackout
            g2.setColor(new Color(6, 3, 1, TINT_ALPHA));
            g2.fillRect(0, 0, W, H);

            // 4. Subtle vignette — darkens only the very edges, centre stays clear
            RadialGradientPaint vignette = new RadialGradientPaint(
                W / 2f, H / 2f, Math.max(W, H) * 0.65f,
                new float[]{0.0f, 1.0f},
                new Color[]{new Color(0,0,0,0), new Color(0,0,0,140)});
            g2.setPaint(vignette);
            g2.fillRect(0, 0, W, H);

            // 5. Thin gold shimmer at top edge — professional accent
            g2.setPaint(new java.awt.LinearGradientPaint(0,0,W,0,
                new float[]{0f, 0.5f, 1f},
                new Color[]{new Color(212,175,55,0), new Color(212,175,55,60), new Color(212,175,55,0)}));
            g2.fillRect(0, 0, W, 2);
        } else {
            fallback.setSize(W, H);
            fallback.paint(g2);
        }
        g2.dispose();
        super.paintChildren(g);
    }
}
