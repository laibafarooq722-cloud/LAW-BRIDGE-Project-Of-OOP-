package lawbridge.ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class HomePanel extends JPanel {

    private final MainFrame main;

    public HomePanel(MainFrame main) {
        this.main = main;
        setLayout(new BorderLayout());
        setOpaque(false);

        // Rotating multi-image background
        SlideshowBackground bg = new SlideshowBackground();
        bg.setLayout(new BorderLayout());

        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setOpaque(false);
        body.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        body.add(buildCenteredHero());

        bg.add(body, BorderLayout.CENTER);
        add(bg, BorderLayout.CENTER);

        addHierarchyListener(e -> {
            if ((e.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0 && !isShowing())
                bg.stopAnimation();
        });
    }

    // ── CENTERED HERO ─────────────────────────────────────────────
    private JPanel buildCenteredHero() {
        JPanel outer = new JPanel(new GridBagLayout());
        outer.setOpaque(false);

        JPanel card = new JPanel() {
            float t = 0;
            Timer tm = new Timer(40, e -> { t += 0.03f; repaint(); });
            { tm.start(); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                float glow = (float)(Math.sin(t) * 0.3 + 0.7);
                // Semi-transparent dark glass card
                g2.setColor(new Color(8, 5, 2, 210));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);
                // Animated gold border
                g2.setColor(new Color(212, 175, 55, (int)(140 * glow)));
                g2.setStroke(new BasicStroke(1.8f));
                g2.drawRoundRect(1, 1, getWidth()-2, getHeight()-2, 24, 24);
                // Inner glow at top
                g2.setPaint(new java.awt.GradientPaint(0, 0, new Color(212,175,55,(int)(35*glow)), 0, 60, new Color(0,0,0,0)));
                g2.fillRect(0, 0, getWidth(), 60);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(52, 70, 52, 70));
        card.setPreferredSize(new Dimension(760, 580));
        card.setMaximumSize(new Dimension(760, 580));

        // Animated scale logo
        JPanel logoPanel = new JPanel() {
            float pulse = 0;
            float rotate = 0;
            Timer t = new Timer(30, e -> { pulse += 0.04f; rotate += 0.008f; repaint(); });
            { t.start(); setOpaque(false); setPreferredSize(new Dimension(120, 120)); setMaximumSize(new Dimension(120, 120)); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int cx = getWidth()/2, cy = getHeight()/2;
                float glow = (float)(Math.sin(pulse) * 0.4 + 0.6);
                // Rotating outer ring
                g2.rotate(rotate, cx, cy);
                g2.setColor(new Color(212, 175, 55, (int)(40 * glow)));
                g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 0, new float[]{8, 6}, 0));
                g2.drawOval(cx-52, cy-52, 104, 104);
                g2.rotate(-rotate, cx, cy);
                // Outer glow
                g2.setColor(new Color(212, 175, 55, (int)(60 * glow)));
                g2.fillOval(cx-46, cy-46, 92, 92);
                // Dark fill circle
                g2.setColor(new Color(20, 12, 4));
                g2.fillOval(cx-40, cy-40, 80, 80);
                // Solid gold ring
                g2.setColor(new Color(212, 175, 55, (int)(220 * glow)));
                g2.setStroke(new BasicStroke(2.5f));
                g2.drawOval(cx-40, cy-40, 80, 80);
                // Scale symbol
                g2.setColor(new Color(212, 175, 55));
                g2.setStroke(new BasicStroke(2.2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                // Beam
                g2.drawLine(cx-22, cy-4, cx+22, cy-4);
                // Vertical post
                g2.drawLine(cx, cy-22, cx, cy+16);
                // Base
                g2.drawLine(cx-10, cy+16, cx+10, cy+16);
                // Left pan
                float tilt = (float)(Math.sin(pulse*0.7)*5);
                g2.drawLine(cx-22, cy-4, cx-22, (int)(cy+tilt));
                g2.drawArc(cx-34, (int)(cy+tilt), 24, 12, 0, -180);
                // Right pan (counter-tilt)
                g2.drawLine(cx+22, cy-4, cx+22, (int)(cy-tilt));
                g2.drawArc(cx+10, (int)(cy-tilt), 24, 12, 0, -180);
                g2.dispose();
            }
        };
        logoPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Welcome text
        JLabel welcome = new JLabel("Welcome to LawBridge") {
            float t = 0;
            Timer tm = new Timer(50, e -> { t += 0.025f; repaint(); });
            { tm.start(); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
                float alpha = (float)(Math.sin(t) * 0.08 + 0.92);
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
                // Gold shimmer gradient on text
                g2.setPaint(new java.awt.GradientPaint(
                    0, 0, new Color(255, 230, 130),
                    getWidth(), 0, new Color(180, 130, 40)));
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(getText(), 0, fm.getAscent());
                g2.dispose();
            }
        };
        welcome.setFont(new Font("Georgia", Font.BOLD, 34));
        welcome.setForeground(Theme.GOLD);
        welcome.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Animated gold underline
        JPanel underline = new JPanel() {
            float t = 0;
            Timer tm = new Timer(35, e -> { t += 0.05f; repaint(); });
            { tm.start(); setOpaque(false); setPreferredSize(new Dimension(400, 6)); setMaximumSize(new Dimension(600, 6)); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                float center = (float)(Math.sin(t) * 0.1 + 0.5);
                g2.setPaint(new java.awt.LinearGradientPaint(0, 0, getWidth(), 0,
                    new float[]{0f, center, 1f},
                    new Color[]{new Color(212,175,55,0), new Color(212,175,55,220), new Color(212,175,55,0)}));
                g2.fillRoundRect(0, 0, getWidth(), 3, 3, 3);
                g2.dispose();
            }
        };
        underline.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Tagline
        JLabel tagline = UIComponents.makeLabel("Pakistan's Trusted Digital Legal Advocacy Platform",
            new Font("SansSerif", Font.ITALIC, 13), new Color(180, 140, 80));
        tagline.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Section divider
        JPanel divider = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new java.awt.LinearGradientPaint(0, 0, getWidth(), 0,
                    new float[]{0f, 0.5f, 1f},
                    new Color[]{new Color(212,175,55,0), new Color(212,175,55,100), new Color(212,175,55,0)}));
                g2.fillRect(0, 2, getWidth(), 1);
                g2.dispose();
            }
        };
        divider.setOpaque(false);
        divider.setPreferredSize(new Dimension(500, 5));
        divider.setMaximumSize(new Dimension(Integer.MAX_VALUE, 5));
        divider.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Quotes label
        JLabel quotesHeader = UIComponents.makeLabel("WORDS OF JUSTICE",
            new Font("SansSerif", Font.BOLD, 10), new Color(150, 110, 50));
        quotesHeader.setAlignmentX(Component.CENTER_ALIGNMENT);
        quotesHeader.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));

        // Three bold quotes
        String[][] quotes = {
            {"\u201cInjustice anywhere is a threat\nto justice everywhere.\u201d", "— Martin Luther King Jr."},
            {"\u201cThe law is reason,\nfree from passion.\u201d", "— Aristotle"},
            {"\u201cWhere law ends,\ntyranny begins.\u201d", "— William Pitt"},
        };

        JPanel quotesRow = new JPanel(new GridLayout(1, 3, 16, 0));
        quotesRow.setOpaque(false);
        quotesRow.setAlignmentX(Component.CENTER_ALIGNMENT);

        for (String[] q : quotes) {
            quotesRow.add(buildBoldQuoteCard(q[0], q[1]));
        }

        card.add(logoPanel);
        card.add(Box.createVerticalStrut(20));
        card.add(welcome);
        card.add(Box.createVerticalStrut(10));
        card.add(underline);
        card.add(Box.createVerticalStrut(10));
        card.add(tagline);
        card.add(Box.createVerticalStrut(30));
        card.add(divider);
        card.add(Box.createVerticalStrut(22));
        card.add(quotesHeader);
        card.add(quotesRow);

        outer.add(card);
        return outer;
    }

    private JPanel buildBoldQuoteCard(String text, String author) {
        JPanel card = new JPanel() {
            boolean hov = false;
            { addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){ hov=true; repaint(); }
                public void mouseExited(MouseEvent e){ hov=false; repaint(); }
            });}
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(20, 12, 4, hov ? 230 : 190));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                // Animated gold top bar
                g2.setPaint(new java.awt.GradientPaint(0, 0,
                    new Color(212, 175, 55, hov ? 220 : 160),
                    getWidth(), 0,
                    new Color(180, 130, 40, hov ? 180 : 80)));
                g2.fillRoundRect(0, 0, getWidth(), 4, 4, 4);
                g2.setColor(new Color(212, 175, 55, hov ? 160 : 80));
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 14, 14);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(18, 16, 18, 16));
        card.setPreferredSize(new Dimension(0, 115));

        // Large decorative quote mark
        JLabel quoteIcon = new JLabel("\u201c");
        quoteIcon.setFont(new Font("Georgia", Font.BOLD, 40));
        quoteIcon.setForeground(new Color(212, 175, 55, 80));
        quoteIcon.setAlignmentX(Component.LEFT_ALIGNMENT);
        quoteIcon.setBorder(BorderFactory.createEmptyBorder(-10, 0, -14, 0));

        JLabel qText = UIComponents.makeLabel(
            "<html><body style='width:165px; font-size:12px; font-weight:bold; color:#F0DDA0; line-height:1.5;'>"
            + text.replace("\n", "<br>") + "</body></html>",
            new Font("Georgia", Font.BOLD, 13), Theme.GOLD_LIGHT);
        qText.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel qAuth = UIComponents.makeLabel(author,
            new Font("Georgia", Font.BOLD | Font.ITALIC, 11), new Color(160, 120, 60));
        qAuth.setAlignmentX(Component.LEFT_ALIGNMENT);
        qAuth.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        card.add(quoteIcon);
        card.add(qText);
        card.add(qAuth);
        return card;
    }
}
