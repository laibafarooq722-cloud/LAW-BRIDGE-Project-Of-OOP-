package lawbridge.ui;

import lawbridge.data.DataStore;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class AboutPanel extends JPanel {
    private final DataStore ds = DataStore.getInstance();

    public AboutPanel() {
        setLayout(new BorderLayout());
        setOpaque(false);

        add(buildHeader(), BorderLayout.NORTH);

        // Background: law books image
        ImageBackground bg = new ImageBackground(ImageBackground.ImageType.LAW_BOOKS);
        bg.setLayout(new BorderLayout());

        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setOpaque(false);
        body.setBorder(BorderFactory.createEmptyBorder(22,32,28,32));

        body.add(buildHero());
        body.add(vs(18));
        body.add(buildPlatformStats());
        body.add(vs(18));
        body.add(buildCaseBreakdown());
        body.add(vs(18));
        body.add(buildTeam());
        body.add(vs(18));
        body.add(buildMission());
        body.add(vs(12));

        JScrollPane sp = styledScroll(body);
        bg.add(sp, BorderLayout.CENTER);
        add(bg, BorderLayout.CENTER);

        addHierarchyListener(e -> {
            if ((e.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0 && !isShowing())
                bg.stopAnimation();
        });
    }

    private Component vs(int h) { return Box.createVerticalStrut(h); }

    private JScrollPane styledScroll(JPanel c) {
        JScrollPane sp = new JScrollPane(c);
        sp.setOpaque(false); sp.getViewport().setOpaque(false);
        sp.setBorder(null);
        sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        sp.getVerticalScrollBar().setUnitIncrement(20);
        sp.getVerticalScrollBar().setPreferredSize(new Dimension(5,0));
        sp.getVerticalScrollBar().setUI(new javax.swing.plaf.basic.BasicScrollBarUI(){
            @Override protected void configureScrollBarColors(){
                thumbColor=new Color(212,175,55,100); trackColor=new Color(20,12,4,60);}
            @Override protected JButton createDecreaseButton(int o){JButton b=new JButton();b.setPreferredSize(new Dimension(0,0));return b;}
            @Override protected JButton createIncreaseButton(int o){JButton b=new JButton();b.setPreferredSize(new Dimension(0,0));return b;}
        });
        return sp;
    }

    private Component secHeader(String text) {
        JPanel p = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2=(Graphics2D)g.create();
                g2.setPaint(new GradientPaint(0,getHeight()-1,Theme.GOLD,
                        getWidth()*0.5f,getHeight()-1,new Color(212,175,55,0)));
                g2.drawLine(0,getHeight()-1,getWidth(),getHeight()-1);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        JLabel lbl = UIComponents.makeLabel(text, new Font("Georgia",Font.BOLD,15), Theme.GOLD_LIGHT);
        lbl.setBorder(BorderFactory.createEmptyBorder(0,0,8,0));
        p.add(lbl, BorderLayout.WEST);
        return p;
    }

    private JPanel buildHeader() {
        JPanel h = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                GradientPaint gp=new GradientPaint(0,0,Theme.BG_MEDIUM,getWidth(),0,Theme.BG_DARK);
                g2.setPaint(gp); g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(Theme.BORDER); g2.drawLine(0,getHeight()-1,getWidth(),getHeight()-1);
                g2.dispose();
            }
        };
        h.setPreferredSize(new Dimension(0,68));
        h.setLayout(new FlowLayout(FlowLayout.LEFT,24,16));
        // Draw "i" icon instead of emoji
        JPanel iPanel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(212,175,55,40)); g2.fillOval(0,0,32,32);
                g2.setColor(Theme.GOLD); g2.setStroke(new BasicStroke(1.5f));
                g2.drawOval(1,1,30,30);
                g2.setFont(new Font("Georgia",Font.BOLD,16));
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString("i",(32-fm.stringWidth("i"))/2,16+fm.getAscent()/2-3);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize(){return new Dimension(32,32);}
        };
        iPanel.setOpaque(false);
        h.add(iPanel);
        h.add(UIComponents.makeLabel("About LawBridge",new Font("Georgia",Font.BOLD,20),Theme.TEXT_WHITE));
        h.add(UIComponents.makeLabel("  Our story, mission and impact across Pakistan.",
                new Font("SansSerif",Font.PLAIN,12),Theme.TEXT_SECONDARY));
        return h;
    }

    private JPanel buildHero() {
        JPanel card = new JPanel() {
            float t=0; Timer tm=new Timer(40,e->{t+=0.04f;repaint();}); {tm.start();}
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(16,9,3,215)); g2.fillRoundRect(0,0,getWidth(),getHeight(),18,18);
                float glow=(float)(Math.sin(t)*0.3+0.7);
                g2.setColor(new Color(212,175,55,(int)(120*glow)));
                g2.setStroke(new BasicStroke(1.4f));
                g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,18,18);
                g2.dispose(); super.paintComponent(g);
            }
        };
        card.setLayout(new BoxLayout(card,BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(24,28,24,28));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE,200));
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel badge=new JLabel("FOUNDED 2017");
        badge.setFont(new Font("SansSerif",Font.BOLD,9)); badge.setForeground(Theme.GOLD);
        badge.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(212,175,55,60),1),
            BorderFactory.createEmptyBorder(3,8,3,8)));
        badge.setOpaque(true); badge.setBackground(new Color(212,175,55,20));
        badge.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel n=UIComponents.makeLabel("LawBridge Pakistan",new Font("Georgia",Font.BOLD,25),Theme.GOLD_LIGHT);
        JLabel tg=UIComponents.makeLabel("Bridging the Gap Between Justice and the People",
                new Font("Georgia",Font.BOLD,14),Theme.TEXT_WHITE);
        JLabel d=UIComponents.makeLabel(
            "<html><body style='width:680px;font-size:12px;color:#BCA070;line-height:1.5'>"
            +"Founded in 2017, LawBridge is Pakistan's premier digital legal advocacy platform. "
            +"We believe quality legal representation must be accessible to every citizen regardless "
            +"of background. From Karachi to Peshawar, we have helped thousands of families "
            +"navigate the complex legal system with confidence.</body></html>",
            Theme.FONT_BODY, Theme.TEXT_SECONDARY);
        n.setAlignmentX(Component.LEFT_ALIGNMENT);
        tg.setAlignmentX(Component.LEFT_ALIGNMENT);
        d.setAlignmentX(Component.LEFT_ALIGNMENT);

        card.add(badge); card.add(Box.createVerticalStrut(10));
        card.add(n); card.add(Box.createVerticalStrut(5));
        card.add(tg); card.add(Box.createVerticalStrut(10)); card.add(d);
        return card;
    }

    private JPanel buildPlatformStats() {
        JPanel wrap=new JPanel(new BorderLayout(0,10)); wrap.setOpaque(false);
        wrap.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrap.add(secHeader("Platform Statistics"), BorderLayout.NORTH);
        JPanel grid=new JPanel(new GridLayout(2,3,12,12)); grid.setOpaque(false);
        Object[][] d = {
            {"1,247","Total Cases",    new Color(212,175,55)},
            {"983",  "Cases Won",      new Color(72,200,90)},
            {"264",  "Cases Lost",     new Color(220,90,90)},
            {"18",   "Expert Lawyers", Theme.GOLD},
            {"1,543","Happy Clients",  new Color(195,145,75)},
            {"8",    "Years Active",   new Color(60,160,240)},
        };
        for (Object[] row : d) grid.add(bigStatCard((String)row[0],(String)row[1],(Color)row[2]));
        wrap.add(grid, BorderLayout.CENTER);
        return wrap;
    }

    private JPanel buildCaseBreakdown() {
        JPanel wrap=new JPanel(new BorderLayout(0,10)); wrap.setOpaque(false);
        wrap.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrap.add(secHeader("Cases by Practice Area"), BorderLayout.NORTH);
        JPanel grid=new JPanel(new GridLayout(2,3,12,12)); grid.setOpaque(false);
        Object[][] d = {
            {"Criminal Law", 310,270,40,"CR"},
            {"Family Law",   240,210,30,"FM"},
            {"Property Law", 260,225,35,"PR"},
            {"Corporate Law",145,125,20,"CO"},
            {"Civil Law",    230,195,35,"CI"},
            {"Labour Law",   270,235,35,"LB"},
        };
        for (Object[] r : d)
            grid.add(areaCard((String)r[0],(int)r[1],(int)r[2],(int)r[3],(String)r[4]));
        wrap.add(grid, BorderLayout.CENTER);
        return wrap;
    }

    private JPanel buildTeam() {
        JPanel wrap=new JPanel(new BorderLayout(0,10)); wrap.setOpaque(false);
        wrap.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrap.add(secHeader("Our Team"), BorderLayout.NORTH);
        JPanel grid=new JPanel(new GridLayout(1,4,12,0)); grid.setOpaque(false);
        Object[][] d = {
            {"18","Practicing Lawyers",new Color(212,175,55)},
            {"6", "Specializations",   new Color(195,145,75)},
            {"3", "Cities",            new Color(60,160,240)},
            {"8", "Years of Service",  new Color(72,200,90)},
        };
        for (Object[] r : d) grid.add(bigStatCard((String)r[0],(String)r[1],(Color)r[2]));
        wrap.add(grid, BorderLayout.CENTER);
        return wrap;
    }

    private JPanel buildMission() {
        JPanel outer=new JPanel(new BorderLayout(0,10)); outer.setOpaque(false);
        outer.setAlignmentX(Component.LEFT_ALIGNMENT);
        outer.add(secHeader("Our Mission & Values"), BorderLayout.NORTH);

        JPanel card=new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(16,9,3,200)); g2.fillRoundRect(0,0,getWidth(),getHeight(),14,14);
                g2.setColor(new Color(60,38,14,160)); g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,14,14);
                g2.dispose(); super.paintComponent(g);
            }
        };
        card.setLayout(new BoxLayout(card,BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(16,18,16,18));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE,380));
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        String[][] vals = {
            {"J","Justice for All","Every Pakistani citizen deserves quality legal representation regardless of financial standing."},
            {"T","Trust & Transparency","No hidden costs. Complete transparency in fees, case status and lawyer qualifications."},
            {"R","Result-Oriented","Lawyers selected on track record, specialization depth and commitment to client outcomes."},
            {"L","Upholding the Law","Operating with highest ethical standards per Pakistan Bar Council guidelines."},
        };
        for (String[] v : vals) {
            JPanel row=new JPanel(new BorderLayout(12,0));
            row.setOpaque(false);
            row.setBorder(BorderFactory.createEmptyBorder(7,0,7,0));
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE,68));

            JPanel ibadge=new JPanel(new BorderLayout()){
                @Override protected void paintComponent(Graphics g){
                    Graphics2D g2=(Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(new Color(212,175,55,30)); g2.fillOval(0,0,getWidth(),getHeight());
                    g2.setColor(new Color(212,175,55,90)); g2.setStroke(new BasicStroke(1.3f));
                    g2.drawOval(1,1,getWidth()-2,getHeight()-2);
                    g2.dispose(); super.paintComponent(g);
                }};
            ibadge.setOpaque(false); ibadge.setPreferredSize(new Dimension(36,36));
            JLabel iico=UIComponents.makeLabel(v[0],new Font("Georgia",Font.BOLD,16),Theme.GOLD);
            iico.setHorizontalAlignment(SwingConstants.CENTER);
            ibadge.add(iico,BorderLayout.CENTER);

            JPanel txt=new JPanel(); txt.setLayout(new BoxLayout(txt,BoxLayout.Y_AXIS)); txt.setOpaque(false);
            JLabel vt=UIComponents.makeLabel(v[1],new Font("Georgia",Font.BOLD,13),Theme.BROWN_ACCENT);
            JLabel vd=UIComponents.makeLabel(
                "<html><body style='width:580px;font-size:11px;color:#A88050;line-height:1.4'>"+v[2]+"</body></html>",
                Theme.FONT_BODY,Theme.TEXT_SECONDARY);
            vt.setAlignmentX(Component.LEFT_ALIGNMENT); vd.setAlignmentX(Component.LEFT_ALIGNMENT);
            txt.add(vt); txt.add(Box.createVerticalStrut(3)); txt.add(vd);

            row.add(ibadge,BorderLayout.WEST); row.add(txt,BorderLayout.CENTER);
            card.add(row);
            JSeparator s=new JSeparator(); s.setForeground(new Color(212,175,55,28));
            s.setMaximumSize(new Dimension(Integer.MAX_VALUE,1)); card.add(s);
        }
        outer.add(card, BorderLayout.CENTER);
        return outer;
    }

    private JPanel bigStatCard(String val, String lbl, Color accent) {
        JPanel card=new JPanel(){
            boolean hov;
            {addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){hov=true;repaint();}
                public void mouseExited (MouseEvent e){hov=false;repaint();}});}
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(16,9,3,200)); g2.fillRoundRect(0,0,getWidth(),getHeight(),14,14);
                g2.setColor(new Color(accent.getRed(),accent.getGreen(),accent.getBlue(),hov?120:60));
                g2.fillRoundRect(0,0,getWidth(),4,4,4);
                g2.setColor(hov?new Color(accent.getRed(),accent.getGreen(),accent.getBlue(),150):new Color(55,34,10,150));
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,14,14);
                g2.dispose(); super.paintComponent(g);
            }
        };
        card.setLayout(new BoxLayout(card,BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(14,10,14,10));
        card.setPreferredSize(new Dimension(0,105));
        card.setMinimumSize(new Dimension(0,105));
        JLabel v=UIComponents.makeLabel(val,new Font("Georgia",Font.BOLD,26),accent);
        v.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel l=UIComponents.makeLabel(lbl,new Font("SansSerif",Font.PLAIN,11),Theme.TEXT_SECONDARY);
        l.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(Box.createVerticalStrut(8)); card.add(v); card.add(Box.createVerticalStrut(4)); card.add(l);
        return card;
    }

    private JPanel areaCard(String area,int total,int wins,int losses,String abbr) {
        JPanel card=new JPanel(){
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(16,9,3,195)); g2.fillRoundRect(0,0,getWidth(),getHeight(),14,14);
                g2.setColor(new Color(55,34,10,150)); g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,14,14);
                g2.dispose(); super.paintComponent(g);
            }
        };
        card.setLayout(new BoxLayout(card,BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(12,14,12,14));

        JPanel titleRow=new JPanel(new FlowLayout(FlowLayout.LEFT,8,0)); titleRow.setOpaque(false);
        titleRow.setMaximumSize(new Dimension(Integer.MAX_VALUE,28));
        JLabel abbrLbl=UIComponents.makeLabel("["+abbr+"]",new Font("Georgia",Font.BOLD,12),Theme.GOLD);
        JLabel title=UIComponents.makeLabel(area,new Font("Georgia",Font.BOLD,12),Theme.TEXT_WHITE);
        titleRow.add(abbrLbl); titleRow.add(title);
        card.add(titleRow); card.add(Box.createVerticalStrut(8));

        JPanel stats=new JPanel(new GridLayout(1,3,6,0));
        stats.setOpaque(false); stats.setMaximumSize(new Dimension(Integer.MAX_VALUE,48));
        stats.add(miniStat(String.valueOf(total),"Total",Theme.BROWN_ACCENT));
        stats.add(miniStat(String.valueOf(wins),"Wins",Theme.SUCCESS));
        stats.add(miniStat(String.valueOf(losses),"Losses",new Color(220,80,80)));
        card.add(stats); card.add(Box.createVerticalStrut(6));

        int pct=total>0?wins*100/total:0;
        JPanel bar=new JPanel(){
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setFont(new Font("SansSerif",Font.BOLD,10)); g2.setColor(Theme.TEXT_SECONDARY);
                FontMetrics fm=g2.getFontMetrics(); g2.drawString("Win Rate: "+pct+"%",2,fm.getAscent());
                int barY=fm.getHeight()+2;
                g2.setColor(new Color(30,18,7)); g2.fillRoundRect(0,barY,getWidth(),9,6,6);
                int fw=Math.max(getWidth()*pct/100,5);
                g2.setPaint(new GradientPaint(0,0,Theme.SUCCESS,fw,0,Theme.GOLD));
                g2.fillRoundRect(0,barY,fw,9,6,6); g2.dispose();
            }{setOpaque(false);}
        };
        bar.setPreferredSize(new Dimension(0,32)); bar.setMaximumSize(new Dimension(Integer.MAX_VALUE,32));
        card.add(bar);
        return card;
    }

    private JPanel miniStat(String val,String lbl,Color color){
        JPanel p=new JPanel(); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS)); p.setOpaque(false);
        JLabel v=UIComponents.makeLabel(val,new Font("Georgia",Font.BOLD,15),color);
        JLabel l=UIComponents.makeLabel(lbl,new Font("SansSerif",Font.BOLD,10),Theme.TEXT_MUTED);
        v.setAlignmentX(Component.CENTER_ALIGNMENT); l.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(v); p.add(l);
        return p;
    }
}
