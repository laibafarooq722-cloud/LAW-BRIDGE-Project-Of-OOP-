package lawbridge.models;

// INHERITANCE: Lawyer extends Person
public class Lawyer extends Person {

    // ENCAPSULATION: private fields
    private String specialization;
    private int yearsOfExperience;
    private int casesSolved;
    private int wins;
    private int losses;
    private double fees; // per case in PKR
    private String description;

    public Lawyer(String name, int age, String cnic, String specialization,
                  int yearsOfExperience, int casesSolved, int wins, int losses, double fees, String description) {
        super(name, age, cnic);
        this.specialization = specialization;
        this.yearsOfExperience = yearsOfExperience;
        this.casesSolved = casesSolved;
        this.wins = wins;
        this.losses = losses;
        this.fees = fees;
        this.description = description;
    }

    // POLYMORPHISM: implementing abstract method
    @Override
    public String getRole() {
        return "Lawyer - " + specialization;
    }

    // Getters and Setters
    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }

    public int getYearsOfExperience() { return yearsOfExperience; }
    public void setYearsOfExperience(int yearsOfExperience) { this.yearsOfExperience = yearsOfExperience; }

    public int getCasesSolved() { return casesSolved; }
    public void setCasesSolved(int casesSolved) { this.casesSolved = casesSolved; }

    public int getWins() { return wins; }
    public void setWins(int wins) { this.wins = wins; }

    public int getLosses() { return losses; }
    public void setLosses(int losses) { this.losses = losses; }

    public double getFees() { return fees; }
    public void setFees(double fees) { this.fees = fees; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDisplayName() {
        return getName() + " (" + specialization + ") - Rs. " + (int)fees + "/case";
    }

    // POLYMORPHISM: overriding toString
    @Override
    public String toString() {
        return super.toString() + " | Specialization: " + specialization
             + " | Experience: " + yearsOfExperience + " yrs | Fees: Rs." + (int)fees;
    }
}
