package lawbridge.models;

// INHERITANCE: Client extends Person
public class Client extends Person {

    // ENCAPSULATION: private fields specific to client
    private String bForm;
    private String fatherName;
    private String motherName;
    private String fatherCnic;
    private int numberOfSiblings;
    private String phoneNumber;
    private String caseType;
    private String caseDetails;
    private String selectedLawyer;

    public Client(String name, int age, String cnic) {
        super(name, age, cnic); // calling parent constructor
    }

    // POLYMORPHISM: implementing abstract method from Person
    @Override
    public String getRole() {
        return "Client";
    }

    // Getters and Setters
    public String getBForm() { return bForm; }
    public void setBForm(String bForm) { this.bForm = bForm; }

    public String getFatherName() { return fatherName; }
    public void setFatherName(String fatherName) { this.fatherName = fatherName; }

    public String getMotherName() { return motherName; }
    public void setMotherName(String motherName) { this.motherName = motherName; }

    public String getFatherCnic() { return fatherCnic; }
    public void setFatherCnic(String fatherCnic) { this.fatherCnic = fatherCnic; }

    public int getNumberOfSiblings() { return numberOfSiblings; }
    public void setNumberOfSiblings(int numberOfSiblings) { this.numberOfSiblings = numberOfSiblings; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public String getCaseType() { return caseType; }
    public void setCaseType(String caseType) { this.caseType = caseType; }

    public String getCaseDetails() { return caseDetails; }
    public void setCaseDetails(String caseDetails) { this.caseDetails = caseDetails; }

    public String getSelectedLawyer() { return selectedLawyer; }
    public void setSelectedLawyer(String selectedLawyer) { this.selectedLawyer = selectedLawyer; }

    // POLYMORPHISM: overriding toString
    @Override
    public String toString() {
        return super.toString() + " | Role: " + getRole() + " | Case: " + caseType;
    }
}
