package lawbridge.models;

// ABSTRACTION: Abstract class with abstract method
public abstract class Person {

    // ENCAPSULATION: private fields
    private String name;
    private int age;
    private String cnic;

    public Person(String name, int age, String cnic) {
        this.name = name;
        this.age = age;
        this.cnic = cnic;
    }

    // Getters and Setters (Encapsulation)
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getCnic() { return cnic; }
    public void setCnic(String cnic) { this.cnic = cnic; }

    // ABSTRACTION: Abstract method - every person must describe themselves
    public abstract String getRole();

    // POLYMORPHISM: overridden toString in subclasses
    @Override
    public String toString() {
        return "Name: " + name + " | Age: " + age + " | CNIC: " + cnic;
    }
}
