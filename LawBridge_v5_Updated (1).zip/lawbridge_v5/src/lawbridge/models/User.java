package lawbridge.models;

// ENCAPSULATION: User model stores profile data, accessible only via methods
public class User {

    private String username;
    private String password;
    private String email;
    private String fullName;   // saved after first login

    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email    = email;
        this.fullName = username; // default display name
    }

    // Getters & setters
    public String getUsername()  { return username; }
    public String getPassword()  { return password; }
    public String getEmail()     { return email; }
    public String getFullName()  { return fullName; }
    public void   setFullName(String n) { this.fullName = n; }

    public boolean checkPassword(String input) { return this.password.equals(input); }

    // Two-letter initials for avatar circle
    public String getInitials() {
        String n = fullName.trim();
        String[] parts = n.split("\\s+");
        if (parts.length >= 2)
            return ("" + parts[0].charAt(0) + parts[1].charAt(0)).toUpperCase();
        return n.substring(0, Math.min(2, n.length())).toUpperCase();
    }
}
